<?php include('header.php'); ?>
<style>
    #errmsg
{
color: red;
}
 #errmsg1
{
color: red;
}
 #success
{
color: red;
}
</style>


<div class="content-wrapper" style="min-height: 916px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Our Courses</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="box box-warning">
            
            <!-- /.box-header -->
            <div class="box-body">
              <form role="form" method="post" action="" id="myForm">
                <!-- text input -->
                <div class="form-group">
                  <label>Course Name</label>
                  <input type="text" class="form-control" placeholder="Enter  Course Name..." name="course">
                </div>
                <div class="form-group">
                  <label>Select</label>
                  <select class="form-control" name="CourseType">
                    <option value="1">Merit</option>
                    <option value="2">Non Merit</option>
                  </select>
                </div>
               <div class="form-group">
                  <label>Availabe Seats</label>
            	<input type="text" name="availabe" id="quantity" class="form-control" placeholder="Enter  Availabe Seats..." />&nbsp;<span id="errmsg"></span>
                </div>
				
				<div class="checkbox" style="display:none;">
                  <label>
                    <input type="checkbox" id="chkCoreSubjectModifiable"  value="0" />Student has the option to choose from core subjects
                    <input type="hidden" class="form-control" id="test" value="0" name="chkCoreSubjectModifiable">
                  </label>
                </div>
                
				<!-- select -->
                <div class="form-group">
                  <label>Duration of course</label>
              <select class="form-control" name="sem">
				  <?php for($i=1; $i<=10; $i++){ ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?> Semesters</option>
				  <?php } ?>
                  </select>
                  
                </div>
              <button type="submit" class="btn btn-primary" name="submit">Submit Course</button>
              

              </form>
              <script>
   $('#myForm').on('change', 'input[type=checkbox]', function() {
                this.checked ? this.value = '1' : this.value = '0';
                 var x=this.value ;
               // alert(x);
                $('#test').val(x);
            });
          
</script>
              <span id="success"></span>
             <?php  if(isset($_POST['submit']))
{
 // print_r($_POST); die;
    $dat=date("d-m-y");
   $course=$_POST['course'];
   $type=$_POST['CourseType'];
   $availabe=$_POST['availabe'];
   $modifiable=$_POST['chkCoreSubjectModifiable'];
   //echo 'checked/unchecked'.$modifiable; die;
    $ur=$_POST['ur'];
     $sc=$_POST['sc'];
      $obc=$_POST['obc'];
        $sem=$_POST['sem'];
        //$str=implode(',',$sem);
       // print_r($sem);
        //echo $str; die;
        $query="INSERT INTO course (`CourseType`,`coursename`, `available_seats`, `subjectmodifiable` , `duration`, `coursedate`) VALUES ('$type','$course', '$availabe', '$modifiable', '$sem', '$dat');";
        //echo $query;
        $result=mysqli_query($conn,$query);
        if ($result)
        {
          echo '<div id="success_message" class="ajax_response" style="float:left; text-transform:uppercase; margin:2% 37%; Font-weight:bold; color:red">Course added successfully</div>';
 // echo '<script>$("#success").html("Course added successfully).show().fadeOut("slow");</script>';
        }
   
}?>
            </div>
            <!-- /.box-body -->
          </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include('footer.php'); ?>
