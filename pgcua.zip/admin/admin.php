<?php include('header.php');
 if(@$_REQUEST['action'] == 'delete')
 {
     $id=$_GET['id'];
     $query="DELETE FROM admin WHERE id=$id";
       $result= mysqli_query($conn, $query);
      if($result)
   {
       echo '<script>alert("Delete Successfully")</script>'; 
      // header('Location:student.php');
   }
 }

?>

<div class="content-wrapper" style="min-height: 916px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Hover Data Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Admin ID</th>
                <th>Admin Name</th>
                <th>Admin Email</th>
               <!-- <th>Action</th> -->
                
            </tr>
        </thead>
       
        <tbody>
           <?php
                   $query="SELECT * FROM admin";
                   $result= mysqli_query($conn, $query);
                   $i=1;
                   foreach($result as $key=>$val)
                   {
                   //print_r($val);
                   ?>
				<tr role="row" class="odd">
                  <td class=""><?php echo $val['id'];; ?></td>
                  <td class=""><?php echo $val['admin']; ?></td>
                  <td class=""><?php echo $val['email']; ?></td>
              <!--    <td><a style="margin: 0 5px;" href="adminview.php?id=<?php echo $val['id']; ?>"><i class="fa fa-fw fa-eye"></i></a><!--<a style="margin: 0 5px;" href="?action=delete&id=<?php echo $val['id']; ?>" onclick="return confirm('Are you sure you want to delete')"><i class="fa fa-fw fa-trash"></i></a>--></td>-->
                </tr>
                <?php $i++;
                } ?>
        </tbody>
    </table>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php include('footer.php');

?>