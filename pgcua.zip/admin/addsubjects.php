<?php 
include('header.php');
$course=mysqli_query($conn,'SELECT id, coursename FROM course');
?>
<div class="content-wrapper" style="min-height: 916px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Add Subjects</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
		
			<form action="" role="form" id="add_subject" method="post">
			<div class="form-group">
                  <label>Type of subject</label>
                  <select class="form-control" name="type">
				  <option>Select</option>
                    <option value="1">Core Subjects</option>
                    <option value="2">Skill Enhancement Course</option>
					 <option value="3">IEC</option>
                  </select>
                </div>
				<div class="form-group">
                  <label>Select Course</label>
                  <select class="form-control" onchange="fetch(this.value)" name="course">
				    <option>Select</option>
				    <?php foreach($course as $c=>$val) {
				    ?>
                    <option value="<?php echo $val['id'];?>"><?php echo $val['coursename'];?></option>
                    <?php } ?>
                  </select>
                </div>
                <div id="response">
			
                </div>
				<div class="box-footer">
                <button type="button" class="btn btn-primary" id="proceed">Proceed</button>
                <button type="submit" class="btn btn-danger pull-right" id="clr">Reset</button>
              </div>
              <div id="subjects"></div>
             
				</form> <script>
   $('#add_subject').on('change', 'input[type=checkbox]', function() {
                this.checked ? this.value = '1' : this.value = '0';
                 var x=this.value ;
               // alert(x);
               // $('#test').val(x);
            });
          
</script>
				<?php 
				if(isset($_POST['add']))
				{
				  // print_r($_POST); //die;
				    $type=$_POST['type'];
				    $course=$_POST['course'];
				    $sem=$_POST['semester_subject'];
				    $dat=date("d-m-y");
				    $sub=$_POST['sub'];
					$chk=$_POST['chkCoreSubjectModifiable'];
					echo $chk; //die;
																	
				    foreach($sub as $val)
				   {
					 /* $limit=$_POST['limit'];
					// echo $limit;  
					for ($i = 1; $i <= $limit; $i++) {
													$check = $_POST['chkCoreSubjectModifiable' . $i];
													//echo $check; //die;
										*/
					        $query="INSERT INTO `subjects` (`type`, `subject`, `course`,`subjectmodifiable`,`semester`, `created`) VALUES ('$type', '$val', '$course','0', '$sem', '$dat')";
							echo $query.'<br/>';
							$result=mysqli_query($conn,$query);
							echo $result;
							//} exit;
							
					
					   }  if($result)
				        {  echo '<div id="success_message" class="ajax_response" style="float:left; text-transform:uppercase; margin:2% 37%; Font-weight:bold; color:red">Subjects added successfully</div>'; }
					  
				    } 
				?>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('footer.php');?>