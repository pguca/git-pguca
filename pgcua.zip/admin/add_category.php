<?php include('header.php');?>
<div class="content-wrapper" style="min-height: 916px;">
    <!-- Content Header (Page header) -->
	<?php
	
date_default_timezone_set('asia/kolkata');
	if(isset($_POST['submit']))
	{

 $txt_categorey =$_POST['txt_categorey'];	
 $dat=date('d-m-Y H:i:m');
 
 $strut_query = mysqli_query($conn,"INSERT INTO `category`(`category`, `date`) VALUES('".$txt_categorey."','".$dat."')");
	if($strut_query)
	{
		echo "<script type='text/javascript'> alert('Category Add Successfully');</script>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Category can not Add');</script>";
	}	
}
	else if(@$_REQUEST['action'] == 'delete')
 {
     $id=$_GET['id'];
     $query="DELETE FROM category WHERE category_id=$id";
       $result= mysqli_query($conn, $query);
      if($result)
   {
      echo "<script type='text/javascript'> alert('Delete records successfully');</script>";
   }
 }
 else if(isset($_POST['update']))
 {
    $txtc_id =$_POST['txtc_id'];	
    $txt_categorey2 =$_POST['txt_categorey2'];	
   
 $strut_query = mysqli_query($conn,"UPDATE  `category` SET `category`='".$txt_categorey2."' where category_id='".$txtc_id."'");
	if($strut_query)
	{
		echo "<script type='text/javascript'> alert('Category Update Successfully');</script>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Category can not Update');</script>";
	}	
 }
	?>
    <section class="content-header">
	<style>

.txt
	{
		width:100% ! important;
	}
#btnSubmit
	{
		    margin-top: 1%;
	}
	</style>
      <h1>
        Category  Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Category Tables</li>
      </ol>
    </section>
	 
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Category Information</h3></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php 
			
					if(isset($_GET['action']) && $_GET['action']=='edit')
					  {    
						$query_cat = mysqli_query($conn,"SELECT * FROM category WHERE category_id='".$_GET[edit_id]."' ");
						$num_cat = mysqli_num_rows($query_cat);
						$row_cat = mysqli_fetch_array($query_cat);
						
				?>
			  
               <form action="" method="post">
			   <input type="hidden" name="txtc_id" value="<?php echo $row_cat['category_id'];?>">
              <div class="box-body">
                <div class="col-sm-6">
                  <label for="exampleInputEmail1">Category</label>
                   <div class="form-group">
                      <input type="text" class="form-control alphaonly" value="<?php echo $row_cat['category'];?>" id="txt_categorey2" name="txt_categorey2">
                   </div>
                </div>
                <div class="col-sm-6">
                  <label for="exampleInputPassword1"></label>
					<div class="form-group">
                   <input type="submit" id="btnSubmit" class="btn btn-warning"  name="update" value="UPDATE">
					</div>
                </div>
                
              </div>
			  </form>
					  <?php
					  }
					  else
					  {
						  ?>
					   <form action="" method="post">
              <div class="box-body">
                <div class="col-sm-6">
                  <label for="exampleInputEmail1">Category</label>
                   <div class="form-group">
                      <input type="text" class="form-control alphaonly" placeholder="Enter Category" id="txt_categorey" name="txt_categorey">
                   </div>
                </div>
                <div class="col-sm-6">
                  <label for="exampleInputPassword1"></label>
					<div class="form-group">
                   <input type="submit" id="btnSubmit" class="btn btn-primary"  name="submit" value="SAVE">
					</div>
                </div>
                
              </div>
			  </form>
			  
			  <?php
					  }
					  ?>
			  <div class="box-body">
                 <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">
                   <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Sr No.</th>
                <th>Category Name</th>
                <th>Date</th>
                <th>Action</th>
                
            </tr>
        </thead>
        
        <tbody>
          <?php
		    $struct_query = "Select * from category";
			 $result= mysqli_query($conn, $struct_query);
                   $i=1;
                   foreach($result as $key=>$val)
                   {
					  
						
				  ?>
				<tr role="row" class="odd">
                  <td class=""><?php echo $i; ?> </td>
				  <td class=""><?php echo $val['category']; ?></td>
                  <td class=""><?php echo $val['date']; ?></td>
                  <td>
				    <a href="?action=edit&amp;edit_id=<?php echo $val['category_id']; ?>"><i class="fa fa-fw fa-eye"></i></a>
					  <a href="?action=delete&amp;id=<?php echo $val['category_id']; ?>"><i class="fa fa-fw fa-trash"></i></a>
               
				  </td>
                </tr>
                <?php
				 $i++;
				   }
				   ?>
        </tbody>
    </table>

                  </div>
                </div>
              </div>
                  
              
                
              </div>
            
            <form>
          </div>
        </div>
      </div>
    </section>
  </div>
  <script>

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
$('.alphaonly').bind('keyup blur',function(){ 
    var node = $(this);
    node.val(node.val().replace(/[^a-z]/g,'') ); }
);
</script>
 <?php include('footer.php');?>