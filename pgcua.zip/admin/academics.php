<?php include('header.php');
 
if(@$_REQUEST['action'] == 'delete')
 {
    $id=$_GET['id'];
    // echo $id;
     $query="DELETE FROM  registration WHERE id=$id";
       $result= mysqli_query($conn, $query);
      if($result)
   {
       echo '<script>alert("Delete Successfully"); window.location.href = "basicprofile.php";</script>'; 
      // header('Location:courses.php');
   }
 }


?>

<div class="content-wrapper" style="min-height: 916px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">View Courses</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Sr No.</th>
                <th>Student Name</th>
                <th>Father Name</th>
                <th>Mother Name</th>
                <th>Address</th>
                <th>State</th>
                <th>Country</th>
                  <th>Mobile No.</th>
                <th>Parent/Guardianm Contact No.</th>
                <th>Student id</th>
                <th>Action</th>
                
            </tr>
        </thead>
        
        <tbody>
           <?php
                   $query="SELECT * FROM registration";
                   $result= mysqli_query($conn, $query);
                   $i=1;
                   foreach($result as $key=>$val)
                   {
                   //print_r($val);
                  $id = $val['studid'];
                  $primary=$val['id'];
                //  $enc_id=encryptIt($id);
                //  $pri_id=encryptIt($primary);
                //   include('encdec.php'); 
                   ?>
				<tr role="row" class="odd">
                  <td class=""><?php echo $i; ?></td>
                  <td class=""><?php echo $val['studentname']; ?></td>
                  <td class=""><?php echo $val['fathername']; ?></td>
                  <td class=""><?php echo $val['mothername']; ?></td>
                  <td class=""><?php echo $val['address']; ?></td>
                  <td class=""><?php echo $val['state']; ?></td>
                  <td class=""><?php echo $val['country']; ?></td>
                  <td class=""><?php echo $val['mobileno']; ?></td>
                  <td class=""><?php echo $val['fatherno'].",".$val['landlineno']; ?></td> 
                  <td class=""><?php echo $val['studid']; ?></td>
<td><a style="margin: 0 5px;" href="viewinfo.php?action=show&dataid=<?php echo $id; ?>&name=<?php echo $val['studentname']; ?>&father=<?php echo $val['fathername']; ?>&time=<?php echo $val['date']; ?>"><i class="fa fa-fw fa-eye"></i></a><a style="margin: 0 5px;" onclick="return confirm('Are you sure you want to delete')" href="?action=delete&id=<?php echo $primary; ?>"><i class="fa fa-fw fa-trash"></i></a></td>
                </tr>
                <?php $i++;
                }
               ?>
        </tbody>
    </table>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<?php include('footer.php');

?>