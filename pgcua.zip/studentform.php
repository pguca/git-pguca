 <?php include_once ('header.php');?>
    
     <div class="well">
      
    	  <div class="container" style="width: 77%;">
		       <span id="mms">Welcome "<?php echo $stud_row['studentname'];?>" in your Portal</span>
           </div>
	   <span style="text-align: center;display: inline-block;width: 100%;font-size: 20px;color: red;">Please move forward by filling your personal information.</span>
        
     
    </div>

   
 <?php include_once ('footer.php');?>