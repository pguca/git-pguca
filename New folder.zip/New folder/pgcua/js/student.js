$(document).ready(function (e) {
 /*$("#form").on('submit',(function(e) {
e.preventDefault();

$('#loadinges').show();
$.ajax({
url: "challan_upload.php", // Url to which the request is send
type: "POST",             // Type of request to be send, called as method
data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
contentType: false,       // The content type used when sending data to the server.
cache: false,             // To unable request pages to be cached
processData:false,        // To send DOMDocument or non processed data file it is set to false
success: function(data)   // A function to be called if request succeeds
{
	if(data=="ok")
	{
		
		$('.challan_success').css("display","block");
		$('.challan_error').css("display","none");
		$('#loadinges').hide();
	}
	else
	{
		$('.challan_success').css("display","block");
		$('.challan_error').css("display","none");
		$('#loadinges').hide();
		
		
	}
}
});
}));   */
 // Function to preview image after validation
$(function() {
$("#fileess").change(function() {
$("#message9").empty(); // To remove the previous error message
  myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
	}
else
	{
		$("#message9").html("<p id='error'>Select Only Pdf File </p>");
		return false;
	}
});
});
function imageIsLoadedssss(e) 
	{
		$("#fileess").css("color","green");
	};
});
$(document).ready(function(){
    $('#ddlpassstatus').on('change', function() {
      if (this.value == "Awaited")
		  {
			$("#demo").css("background-color","green");
			$(".demo1").prop("disabled",true);
			$(".demo1").val(" ");			
			$(".demo2").prop("disabled",true);
			$(".demo2").val(" ");
			$(".demo3").prop("disabled",true);
			$(".demo3").val(" ");
			$(".demo4").prop("disabled",true);
			$(".demo4").val(" ");
			$(".demo5").prop("disabled",true);
			$(".demo5").val(" ");
			$(".demo6").prop("disabled",true);
			$(".demo6").val(" ");
			$(".demo7").prop("disabled",true);
			$(".demo7").val(" ");
			$(".demo8").prop("disabled",true);
			$(".demo8").val(" ");
			$(".demo9").prop("disabled",true);
			$(".demo9").val(" ");
		
		  }
	 else if ( this.value == "Not_Applicable")
		  {
			$("#demo").css("background-color","green");
			$(".demo1").prop("disabled",true);
			$(".demo1").val(" ");			
			$(".demo2").prop("disabled",true);
			$(".demo2").val(" ");
			$(".demo3").prop("disabled",true);
			$(".demo3").val(" ");
			$(".demo4").prop("disabled",true);
			$(".demo4").val(" ");
			$(".demo5").prop("disabled",true);
			$(".demo5").val(" ");
			$(".demo6").prop("disabled",true);
			$(".demo6").val(" ");
			$(".demo7").prop("disabled",true);
			$(".demo7").val(" ");
			$(".demo8").prop("disabled",true);
			$(".demo8").val(" ");
			$(".demo9").prop("disabled",true);
			$(".demo9").val(" ");
		  }
	   else
		  {
			$(".demo1").prop("disabled",false);
			$(".demo2").prop("disabled",false);
			$(".demo3").prop("disabled",false);
			$(".demo4").prop("disabled",false);
			$(".demo5").prop("disabled",false);
			$(".demo6").prop("disabled",false);
			$(".demo7").prop("disabled",false);
			$(".demo8").prop("disabled",false);
			$(".demo9").prop("disabled",false);
			$("#demo").css("background-color","rgba(128, 128, 128, 0)");
		  }
    });
$('.btnview').click(function() {
			var dataid=$(this).attr("data-id");
		 	var dataString = 'dataid=' + dataid ;
		
$.ajax({
type: "POST",
url: "show_studinfo.php?action=show",
data: dataString,
success: function(data)
{
$("#studinfo").html(data);

} 
		}); 
		});
	});
$('input[name="txtradio"]').on('change', function() {
			if($(this).val() == "Yes")
			{
				$('textarea[name="txtdetails"]').attr('disabled', false).focus();
			}
			else
			{
				$('textarea[name="txtdetails"]').attr('disabled', true).focus();
			}
    
});
$(document).ready(function (e) {
	
//$("#uploadimage").on('submit',(function(e) {
//e.preventDefault();
//$("#message7").empty();
//$('#loading').show();
//$.ajax({
//url: "ajax_php_file.php", // Url to which the request is send
//type: "POST",             // Type of request to be send, called as method
//data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
//contentType: false,       // The content type used when sending data to the server.
//cache: false,             // To unable request pages to be cached
//processData:false,        // To send DOMDocument or non processed data file it is set to false
//success: function(data)   // A function to be called if request succeeds
//{
// if(data=="ok")
//	{
//		$('#loading').hide();
//		$(".succs").css("display","none");
//		$(".wrn").css("display","block");
//		$("#btnnext2").css("display","block");
//		$("#btndocupdate").css("display","block");
//		$("#btnsavedoc").css("display","none");
//		$('.education').prop("disabled", false)
//		$('.summary').prop("disabled", false)  
//		$('.payment').prop("disabled", true) 
//		$('.apllication').prop("disabled", true) 
//		 jQuery('html,body').animate({ scrollTop: jQuery('.wrn').offset().top}, 1000);
//	}
//else 
//	{
//		$('#loading').hide();
//		$(".wrn").css("display","none");
//		$(".succs").css("display","block");
//		 jQuery('html,body').animate({ scrollTop: jQuery('.succs').offset().top}, 1000);
//	} 
//}
//});
//}));
	
// Function to preview image after validation
$(function() {
$("#file").change(function() {
$("#message").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{
$('#previewing').attr('src','photo/user.jpg');
$("#message").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});
});
function imageIsLoaded(e) {
$("#file").css("color","green");
$('#image_preview').css("display", "block");
$('#previewing').attr('src', e.target.result);
$('#previewing').attr('width', '250px');
$('#previewing').attr('height', '230px');
};
	// Function to preview image after validation
$(function() {
$("#file2").change(function() {
$("#message2").empty(); // To remove the previous error message
var file2 = this.files[0];
var imagefile2 = file2.type;
var match2= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile2==match2[0]) || (imagefile2==match2[1]) || (imagefile2==match2[2])))
{
$('#previewing2').attr('src','photo/signature.jpg');
$("#message2").html("<p id='error'>Please Select A valid Signature File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoadedss;
reader.readAsDataURL(this.files[0]);
}
});
});
function imageIsLoadedss(e) {
$("#file2").css("color","green");
$('#image_preview2').css("display", "block");
$('#previewing2').attr('src', e.target.result);
$('#previewing2').attr('width', '250px');
$('#previewing2').attr('height', '230px');
};
// Function to  Characters Certificate validation
$(function() {
$("#file6").change(function() {
$("#message6").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
		$("#file6").css("color","green");
	}
else
	{
		$("#file6").css("color","red");
		$("#message6").html("<p id='error'>Select Only Pdf File </p>");
		return false;

	}
});
});
// Function to  Cast Certificate validation
$(function() {
$("#file10").change(function() {
$("#message10").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
		$("#file10").css("color","green");
	}
	else
	{
		$("#file10").css("color","red");
		$("#message10").html("<p id='error'>Select Only Pdf File </p>");
		return false;
	}
});
});
// Function to  Single Girl Certificate validation
$(function() {
$("#file11").change(function() {
$("#message11").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
    {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
		$("#file11").css("color","green");
	}
	else
	{
		$("#file11").css("color","red");
		$("#message11").html("<p id='error'>Select Only Pdf File </p>");
		return false;
	}
});
});
// Function to  Sports Quota Certificate validation
$(function() {
$("#file12").change(function() {
$("#message12").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
		$("#file12").css("color","green");
	}
	else
	{
		$("#file12").css("color","red");
		$("#message12").html("<p id='error'>Select Only Pdf File </p>");
		return false;
	}
});
});
// Function to  Cultural Quota Certificate validation
$(function() {
$("#file13").change(function() {
$("#message13").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
		$("#file13").css("color","green");
	}
	else
	{
		$("#file13").css("color","red");
		$("#message13").html("<p id='error'>Select Only Pdf File </p>");
	   return false;
	}
});
});
// Function to Matric Certificate validation
$(function() {
$("#file5").change(function() {
	$("#message5").empty(); // To remove the previous error message
	myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
	{
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
	}
	else
	{
		$("#message5").html("<p id='error'>Select Only Pdf File </p>");
		return false;

	}
});
});
function imageIsLoadedsss(e)
	{
		$("#file5").css("color","green");
	};
 // Function to Intermediate Certificate  validation
$(function() {
$("#file4").change(function() {
$("#message4").empty(); // To remove the previous error message
 myfile= $( this ).val();
   var ext = myfile.split('.').pop();
   if(ext=="pdf")
   {
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
	}
	else
	{
		$("#message4").html("<p id='error'>Select Only Pdf File </p>");
		return false;

	}
});
});
function imageIsLoadedssss(e) 
	{
		$("#file4").css("color","green");
	};

// Function to Graduation Certificate validation
$(function() {
   $("#file3").change(function()
{
   $("#message3").empty(); // To remove the previous error message
   myfile= $( this ).val();
    var ext = myfile.split('.').pop();
    if(ext=="pdf")
	{
		var reader = new FileReader();
		reader.onload = imageIsLoadedsss;
		reader.readAsDataURL(this.files[0]);
	}
	else
	{
		 $("#message3").html("<p id='error'>Select Only Pdf File </p>");
		 return false;
	}
});
});
function imageIsLoadedsssss(e) 
	{
		$("#file3").css("color","green");
	};
});
function printDiv(divName) 
{
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}
function fetch_select(val)
{
   $.ajax({
     type: 'post',
     url: 'studsemsester.php',
     data: {
       get_option:val
     },
     success: function (response) 
	  {
          $("#he").html(response);
      }
   });
}

	$('input[name="pay"]').on('change', function() {
			if($(this).val() == "Offline")
			{
				$("#btnpayment").show();
				$("#btnpayments").hide();
				$("#btnprint").show();
				$("#reference_id").show();
			}
			else
			{
				$("#btnpayment").hide();
				$("#btnpayments").show();
				$("#btnprint").hide();
				$("#reference_id").hide();
			}
    
});
 function isNumberKeys(evt)
       {
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ( charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57 ))
             return false;

          return true;
       }
function isNumberKeyes(evt)
       {
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if (charCode != 47 && charCode > 31 
            && (charCode < 48 || charCode > 57 ))
             return false;

          return true;
       }
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
/* function isNumberdot(evt)
           {
               var charCode = (evt.which) ? evt.which : event.keyCode
 
               if (charCode == 46)
               {
                   var inputValue = $("#txtgetmarks3").val()
				 if (inputValue.indexOf('.') < 1 )
                   {
                       return true;
                   }
                   return false;
				  if (inputValue.indexOf('.') < 1 )
                   {
                       return true;
                   }
                   return false;
				 
            }
				   
				   
               }
               if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
               {
                   return false;
               }
               return true;
           } */
		   
		   
		   
		   
 function sendContact() {
     $('#loading').show();
	var valid;	
	valid = validateContact();
	
	if(valid) {
		jQuery.ajax({
		url: "insert_user.php?action=addcategory",
		data:'ddlcategory='+$("#ddlcategory").val()+'&ddlsemester='+$("#ddlsemester").val()+'&txtid1='+$("#txtid1").val(),
		type: "POST",
		success:function(data){
            $('#loading').hide();
			if(data=='ok')
			{
                if($("#ddlsemester").val() > 1) {
                     $('#univroll').css('display','block');
                }
                $('#container').css('display','block'); 
		        $(".succ").css("display","block");
			setTimeout(function()
					{
						 $("#btnnext").css("display","block");
						 $("#btnsave").css("display","none");
						 $("#btnupdate").css("display","block");
						 $('.education').prop("disabled", false)
					     $('.summary').prop("disabled", true)  
						 $('.payment').prop("disabled", true) 
						 $('.apllication').prop("disabled", true) 
                        window.location.reload();
					},1000);
			}
			else
			{
			   $(".wrng").css("display","block");
					
			}
		},
		error:function ()
		{
		}
		});
	//}
}
 }
function validateContact() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#ddlcategory").val()) {
		$("#userName-info").html("(required)");
		$("#ddlcategory").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#ddlsemester").val()) {
		$("#userSem-info").html("(required)");
		$("#ddlsemester").css('background-color','#FFFFDF');
		valid = false;
	}
	return valid;
} 

$(document).ready(function() {
	
	
	$('.number').keypress(function(event) {
    var $this = $(this);
    if ((event.which != 46 || $this.val().indexOf('.') != -1) &&
       ((event.which < 48 || event.which > 57) &&
       (event.which != 0 && event.which != 8))) {
           event.preventDefault();
    }

    var text = $(this).val();
    if ((event.which == 46) && (text.indexOf('.') == -1)) {
        setTimeout(function() {
            if ($this.val().substring($this.val().indexOf('.')).length > 3) {
                $this.val($this.val().substring(0, $this.val().indexOf('.') + 3));
            }
        }, 1);
    }

    if ((text.indexOf('.') != -1) &&
        (text.substring(text.indexOf('.')).length > 2) &&
        (event.which != 0 && event.which != 8) &&
        ($(this)[0].selectionStart >= text.length - 2)) {
            event.preventDefault();
    }      
});

$('.number').bind("paste", function(e) {
var text = e.originalEvent.clipboardData.getData('Text');
if ($.isNumeric(text)) {
    if ((text.substring(text.indexOf('.')).length > 3) && (text.indexOf('.') > -1)) {
        e.preventDefault();
        $(this).val(text.substring(0, text.indexOf('.') + 3));
   }
}
else {
        e.preventDefault();
     }
});
	
	
	
	
	
	
$(".btnstudinfo").click(function() {
		var studdataid=$(this).attr("studdata-id");
	    var dataString = "studdataid=" + studdataid ;
		$.ajax({
		type: "POST",
		url: "edit_studentinformation.php?action=show",
		data: dataString,
		success: function(data)
		{
		$("#studpersonalinfo").html(data);
		} 
			}); 
		});
	
$(".btn-pref .btn").click(function () {
    $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");
	$(".start").removeClass("btn-primary").addClass("btn-primary");
    $(this).removeClass("btn-default").addClass("btn-primary");   
});
$("#btnstars").click(function () {
        $(".start").removeClass("btn-default").addClass("btn-primary");
        $(".categorey").addClass("active").addClass("btn-primary"); // instead of this do the below 
 });
/* $("#favoritesee").click(function () {
        $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");
        $("#favoritesee").removeClass("btn-default").addClass("btn-primary");
}); */
$("#btnnext").click(function () {
        $(".categorey").removeClass("btn-primary").addClass("btn-default");
        $(".education").addClass("active").addClass("btn-primary");; // instead of this do the below 
     	$('.education').prop("disabled", false)
		$(".succ").css("display","none");
});
$("#btnnext2").click(function () {
        $(".education").removeClass("btn-primary").addClass("btn-default");
        $(".summary").addClass("active").addClass("btn-primary");; // instead of this do the below 
     	$('.summary').prop("disabled", false)
		$(".succs").css("display","none"); 
		$('.education').prop("disabled", false)
		$('.summary').prop("disabled", false)  
		$('.payment').prop("disabled", true) 
		$('.apllication').prop("disabled", true) 
});
$("#btnnext3").click(function () {
        $(".summary").removeClass("btn-primary").addClass("btn-default");
        $(".payment").addClass("active").addClass("btn-primary");; // instead of this do the below 
     	$('.payment').prop("disabled", false)
		$(".succs").css("display","none");
});
});