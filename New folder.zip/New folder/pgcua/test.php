<?php
include ('config.php');
    $subject_id        = $_GET['subject_id'];
    $course            = $_GET['course'];
    $sem               = $_GET['sem'];
    $subjectids        = explode(",",$_GET['subjectids']);

$output = '';
$innerselect = "SELECT subject_restrict.subject2 FROM subject_restrict where ";

for($k=0;$k<sizeof($subjectids);$k++) { 
    if($k==0){
        $innerselect .= "  subject_restrict.subject1 = ".$subjectids[$k];
    }else{
        $innerselect .= " or subject_restrict.subject1 = ".$subjectids[$k];
    }
    
}
$innerselect .= " UNION SELECT subject_restrict.subject1 FROM subject_restrict where ";

for($l=0;$l<sizeof($subjectids);$l++) { 
    if($l==0){
        $innerselect .= "  subject_restrict.subject2 = ".$subjectids[$l];
    }else{
        $innerselect .= " or subject_restrict.subject2 = ".$subjectids[$l];
    }
    
}

$q = "select * from subjects where subjects.id not in (".$innerselect.") and subjects.course='".$course."' and subjects.semester = '".$sem."' and subjects.subjectmodifiable = 1 and subjects.type = 1 ";

for($k=0;$k<sizeof($subjectids);$k++) { 
    $q .= " and subjects.id != ".$subjectids[$k];
}
echo $q;
$query = mysqli_query($conn,$q);

$output .= "<option value=''>Select</option>";

while($row=mysqli_fetch_array($query)){ 
                
    $output .= "<option value='".$row['id']."'>".$row['subject']."</option>";
    
}	echo $output; ?>
   
