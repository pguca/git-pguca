<style>
.form-group.subjects .col-sm-6 {
    margin: 5px 0;
}
</style>
<?php include_once ('header.php');
    $query_cat = mysqli_query($conn,"SELECT t1.stud_id,t1.`stud_choice_course`, t1.`stud_semester`,t2.coursename,t3.categorey,t3.sportdquotaperson,t3.singlegirlperson,t3.culturalquotaperson FROM `studcourse` t1 INNER JOIN course t2 on t1.stud_choice_course=t2.id INNER JOIN registration t3 on t1.stud_id=t3.studid where t1.stud_id='".@$_SESSION['user_id']."'");
    $query_records=mysqli_query($conn,"SELECT * FROM `studdocument` where studid='".@$_SESSION['user_id']."'");
    $query=mysqli_query($conn,"Select * from course ");
    $query_course=mysqli_query($conn,"Select * from course ");
    
    @$num_cat=mysqli_num_rows($query_cat);
    @$row_cat=mysqli_fetch_array($query_cat);
    @$num_records=mysqli_num_rows($query_records);
    @$row_records=mysqli_fetch_array($query_records);
    
    @$count=mysqli_num_rows($query);
    @$count_course=mysqli_num_rows($query_course);

        $query_sem = mysqli_query($conn,"select duration from course  where id='".$row_cat['stud_choice_course']."'");
        $num_query = mysqli_num_rows($query_sem);
        $rowes=mysqli_fetch_array($query_sem);
        $core_subject_count = mysqli_query($conn,"select core_subject_count from semester_details  where course_id='".$row_cat['stud_choice_course']."' and   semester_id ='".$row_cat['stud_semester']."'  ");
        $num_query              = mysqli_num_rows($core_subject_count);
        $total_core_subjectsdb    = mysqli_fetch_array($core_subject_count);
        $total_core_subjects = $total_core_subjectsdb['core_subject_count'];

    $compulsory = mysqli_query($conn,"SELECT * FROM subjects where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and subjectmodifiable = 0 and type = 1 "); 

    $compulsory_number = mysqli_num_rows($compulsory); 

    $remaining_corses = $total_core_subjects - $compulsory_number;

    $subjectmodifiable = mysqli_query($conn,"SELECT * FROM subjects where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and subjectmodifiable = 1 and type = 1 "); 

    $subjectmodifiable_number = mysqli_num_rows($subjectmodifiable); 

    $sec = mysqli_query($conn,"SELECT * FROM subjects where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and type = 2  "); 

    $sec_num = mysqli_num_rows($sec); 

    $ace = mysqli_query($conn,"SELECT * FROM subjects where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and type = 3 "); 
    
    $ace_num = mysqli_num_rows($ace); 

    $query_student_subject = mysqli_query($conn,"SELECT * FROM `student_subject` WHERE `student_id` = '".@$_SESSION['user_id']."' and `course` = '".@$row_cat['stud_choice_course']."' and `semester` = '".@$row_cat['stud_semester']."'") ; 
    $query_student_subject_numb = mysqli_num_rows($query_student_subject); 
    $query_student_subject_name =  mysqli_query($conn,"SELECT subject FROM `subjects` WHERE subjects.id in ( SELECT subject_id FROM `student_subject` WHERE `student_id` = '".@$_SESSION['user_id']."' and `course` = '".@$row_cat['stud_choice_course']."' and `semester` = '".@$row_cat['stud_semester']."')");

if(isset($_POST['submit_subjects'])){
   // print_r($_POST);exit;
    $course     = $_POST['stud_course'];
    $semester   = $_POST['stud_sem'];
    
    if($_POST['univrollinput'] != NULL) {
        $addrollnumber = mysqli_query($conn,"UPDATE `student` SET `rollnumber` = '".@$_POST['univrollinput']."' WHERE `studentid` = '".@$_SESSION['user_id']."'");
    }
    foreach ($_POST as $param_name => $param_val) {
if($param_name == 'stud_course' || $param_name == 'stud_sem')
continue;

        $insert_stud_sub = "INSERT INTO student_subject (`student_id`, `subject_id`,`course`,`semester`) VALUES ('".@$_SESSION['user_id']."', '$param_val', '$course', '$semester')";
        if(is_numeric ($param_val)){
            mysqli_query($conn,$insert_stud_sub);
        }
    }
    Header('Location: '.$_SERVER['PHP_SELF']);
    Exit(); //optional
}
if(isset($_POST['reset'])){    
    mysqli_query($conn,"DELETE FROM `studcourse` WHERE `stud_id` = '".$_POST['stud_id']."' and stud_semester = '".$_POST['stud_sem_id']."'");
    mysqli_query($conn, "DELETE FROM `student_subject` WHERE `student_id` = '".$_POST['stud_id']."' and semester = '".$_POST['stud_sem_id']."'");
    Header('Location: '.$_SERVER['PHP_SELF']);
Exit(); //optional
}
?>
<script>
    var subjectids   = [];
function modicourse(id,value,course,sem){
    var sel         = id.split("-");
    var selid       = parseInt(sel[1]);
    var nxtid       = parseInt(sel[1])+1;
	if(selid == 1) {
		subjectids   = [];
	}
    subjectids.push(value);
    //alert(subjectid);
        var xmlhttp;
           if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
          }
          else
          {// code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }	
          xmlhttp.onreadystatechange = function() {
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
              document.getElementById("modi-"+nxtid).innerHTML = xmlhttp.responseText;
            }
          }
          xmlhttp.open("GET","test.php?subject_id="+value+"&course="+course+"&sem="+sem+"&subjectids="+subjectids, true);
          xmlhttp.send();
}
    $( document ).ready(function() {
        if($('#univroll').css('display') == 'block'){
            $("#univrollinput").prop('required',true);
        }
    });
</script>
    <div class="btn-pref btn-group btn-group-justified btn-group-lg" role="group" aria-label="...">
		        <div class="btn-group" role="group">
            <button type="button" id="stars" class="btn btn-default categorey"  href="#tab1" data-toggle="tab">
                <div class="hidden-xs">Course</div>
            </button>
        </div>
		
		<?php if($row_records['matricboard']){	?>
        <div class="btn-group" role="group">
            <button type="button"  id="favorites" class="btn btn-default education" href="#tab2" data-toggle="tab">
                <div class="hidden-xs">Education & Document Details</div>
            </button>
        </div>
		<div class="btn-group" role="group">
            <button type="button" id="favorites" class="btn btn-default btnview summary" data-id="<?php echo $_SESSION['user_id'];?>"  href="#tab3" data-toggle="tab">
                <div class="hidden-xs">Application Summary</div>
            </button>
        </div>
		<?php  }else {	?>
		 <div class="btn-group" role="group">
            <button type="button"  id="favorites" class="btn btn-default education" disabled href="#tab2" data-toggle="tab">
                <div class="hidden-xs">Education & Document Details</div>
            </button>
        </div>
		<div class="btn-group" role="group">
            <button type="button" id="favorites" class="btn btn-default summary btnview" disabled href="#tab3" data-id="<?php echo $_SESSION['user_id'];?>"   data-toggle="tab">
                <div class="hidden-xs">Application Summary</div>
            </button>
        </div>
		<?php }	?>
    </div>
     <div class="well" style="background:#fff; min-height:650px;">
      <div class="tab-content">
	 
        <div class="tab-pane fade in active" id="tab1">
            <div class="container" style="width: 77%;">
                <div class="alert alert-success succ">
                    You have choice course sucessfully  .
                </div>
                <div class="alert alert-danger wrng">
                    You have not insert course.
                </div>
                <h2>Course &amp; Semester </h2>
                <div class="form-group"> 
                    <div class="col-sm-6">
                        <label class="control-label" for="email"> Select Course :</label>
                        <span id="userName-info" class="info"></span><br/>
                        <input type="hidden" name="txtid1" id="txtid1" value="<?php echo $_SESSION['user_id'];?>">
                        <select class="form-control demoInputBox" name="ddlcategory" id="ddlcategory" onchange="fetch_select(this.value);" <?php if($query_student_subject_numb > 0){ echo'disabled'; } ?> > 
                            <option value="">Select</option>
                        <?php while(@$row=mysqli_fetch_array($query)){	?>
                            <option value="<?php echo $row['id'];?>" <?php if($row_cat['stud_choice_course'] == $row['id'] ){ echo 'selected'; } ?> ><?php echo $row['coursename'];?></option>
                        <?php }	?>
                        </select>
                    </div>
                    <div class="col-sm-6">
                        <label class="control-label" for="email"> Select Semester :</label>
                        <span id="userSem-info" class="info"></span><br/>
                        <div id="he">
                          <select class="form-control demoInputBox" name="ddlsemester" id="ddlsemester" onchange="sendContact()"  <?php if($query_student_subject_numb > 0){ echo'disabled'; } ?>> 
                              <option value="">Select</option>
                              <?php for ($row = 1; $row <= $rowes['duration']; $row++){ ?>
								   <option <?php if($row_cat['stud_semester'] == $row){ echo'selected'; } ?> value="<?php echo $row; ?>"> <?php echo $row; ?> </option>
	                           <?php } ?>
                          </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container" <?php if($row_cat['stud_choice_course']){ echo'style="display:block;width: 77%; margin-top:3rem"'; }else{ echo'style="display:none;"'; }	?>>
                <?php if($query_student_subject_numb > 0){ ?>
                 <div class="form-group subjects" style="text-align: center;"> 
                            <div class="col-sm-6">
                                <label class="control-label" for="email"> Univ Roll Number</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" readonly="readonly" placeholder="<?php echo $stud_row['rollnumber']; ?>" >
                            </div>
                </div>
                
                <div class="form-group subjects" style="text-align: center;"> 
                    <?php $i=1;
                    while ($row = mysqli_fetch_array($query_student_subject_name)) { ?>
                        <div class="col-sm-6">
                            <label class="control-label" for="email"> <?php echo 'Chosen Subject '. $i; ?></label>
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" readonly="readonly" placeholder="<?php echo $row['subject']; ?>">
                            <input type="hidden" value="<?php //echo $row['id']; ?>" id="comp-<?php echo $i; ?>" name="comp-<?php echo $i; ?>" >
                        </div>
                    <?php    $i++;
                        }
                    ?>
                </div>
    
    
                <?php }else{ ?>
                 <form action="" method="post" enctype="multipart/form-data"> 
                     
                <div class="alert alert-info" style="margin:20px;text-align:center;">
                    Please choose your subjects.
                </div>
                    <div class="form-group subjects" <?php if($row_cat['stud_semester'] > 1){echo "style='text-align: center;display:block; '"; } else {echo'style="text-align: center;display:none;"';}?>  id="univroll"> 
                            <div class="col-sm-6">
                                <label class="control-label" for="email"> Univ Roll Number</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="univrollinput" name="univrollinput">
                            </div>
                        
                    </div>
                    <input type="hidden" value="<?php echo $row_cat['stud_choice_course']; ?>" name="stud_course">
                    <input type="hidden" value="<?php echo $row_cat['stud_semester']; ?>" name="stud_sem">
                    <div class="form-group subjects" style="text-align: center;"> 
                        <?php $i=1;
                        while ($row = mysqli_fetch_array($compulsory)) { ?>
                            <div class="col-sm-6">
                                <label class="control-label" for="email"> <?php echo 'Compulsory Subject '. $i; ?></label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" readonly="readonly" placeholder="<?php echo $row['subject']; ?>">
                                <input type="hidden" value="<?php echo $row['id']; ?>" id="comp-<?php echo $i; ?>" name="comp-<?php echo $i; ?>" >
                            </div>
                        <?php    $i++;
                            }
                        ?>
                    </div>
                
                    <div class="form-group subjects" style="text-align: center;"> 
                        <?php  if($remaining_corses > 1) { ?>
                    <div class="col-sm-6">
                            <label class="control-label" for="email"> <?php echo 'Optional 1'; ?></label>
                    </div>
                    <div class="col-sm-6">
                        <select class="form-control" id="modi-1" onchange="modicourse(this.id,this.value,<?php echo $row_cat['stud_choice_course']?>, <?php echo $row_cat['stud_semester'] ?>)" name="modi-1" required>
						<option value="">Select</option>
                          <?php  
                            for($k=0;$k<$subjectmodifiable_number;$k++) { 
                                while($row = mysqli_fetch_array($subjectmodifiable)){ ?>
                                    <option value="<?php echo $row['id'] ?>"><?php echo $row['subject'] ?></option>
                        <?php    }
                            }
                        ?>
                        </select>
                    </div>
                            <?php    }  ?>
                      <?php  if($remaining_corses > 1) {
                            $modid = 2;
                        for($k=0;$k<$remaining_corses-1;$k++) { ?>
                        <div class="col-sm-6">
                            <label class="control-label" for="email"> <?php echo 'Optional '.$modid; ?></label>
                        </div>
                        <div class="col-sm-6">
                            <select class="form-control" id="modi-<?php echo $modid ?>" onchange="modicourse(this.id,this.value,<?php echo $row_cat['stud_choice_course']?>, <?php echo $row_cat['stud_semester'] ?>)" name="modi-<?php echo $modid ?>" required> 
                                <option value="">Select</option>
                            </select> 
                        </div>
                    <?php  $modid++; } } ?>
                        
                    
                
                <?php  if($sec_num > 0) { ?>
                <div class="col-sm-6">
                    <label class="control-label" for="sec"> <?php echo 'SEC'; ?></label>
                </div>
                <div class="col-sm-6">    
                    <select name="sec" class="form-control" required>
                        <option value="">Select</option>
                        <?php while($row = mysqli_fetch_array($sec)){ ?>
                            <option value="<?php echo $row['id'] ?>" onchange=""><?php echo $row['subject'] ?></option>
                        <?php    }    ?>
                    </select>
                </div>
                        <?php  } if($ace_num > 0) { ?>
                <div class="col-sm-6">
                    <label class="control-label" for="ace"> <?php echo 'Ace'; ?></label>
                </div>
                <div class="col-sm-6">    
                    <select name="ace" class="form-control" required>
                        <option value="">Select</option>
                      <?php while($row = mysqli_fetch_array($ace)){ ?>
                            <option value="<?php echo $row['id'] ?>" onchange=""><?php echo $row['subject'] ?></option>
                        <?php    }    ?>
                    </select>
                </div>
                        <?php  } ?>
                </div>
               
                <?php  } ?>
            </div>
            <div class="form-group">        
                    
                        <?php if($query_student_subject_numb > 0){ ?>
                                <div class="col-sm-offset-5 col-sm-7">
                            <form action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="stud_id" id="stud_id" value="<?php echo $_SESSION['user_id'];?>">
                            <input type="hidden" name="stud_course_id" id="stud_course_id" value="<?php echo $row_cat['stud_choice_course'];?>">
                            <input type="hidden" name="stud_sem_id" id="stud_sem_id" value="<?php echo $row_cat['stud_semester'];?>">
                            <input type="submit" id="reset" name="reset" class="btn btn-success" value="Reset" style="display: block;margin-top: 24px;float: left;margin-right: 30px;">
                            </form>
                            <button type="button"  id="btnnext" class="btn btn-primary" href="#tab2" style="display:block;margin-top:24px;" data-toggle="tab">Next</button>
                 </div>
                        <?php	}else{   ?>
                    <div class="col-sm-offset-5 col-sm-6">

                            <input type="submit" id="btnupdate" name="submit_subjects" class="btn btn-success" style="display:block;margin-top:24px;" value="Save" style="margin-top:24px;">
                            <button type="button"  id="btnnext" class="btn btn-primary" href="#tab2" style="display:block;margin-top:24px;" data-toggle="tab">Next</button>
                    </div>
                        <?php	}	?>
                   
                </div>
        </div>
        </form>

        <div class="tab-pane fade in" id="tab2">
             <div class="alert alert-danger succs">
                You have not upload document .
            </div>
             <div class="alert alert-success wrn">
                You have upload document sucessfully.
            </div>
              <h3>Academic Qualifications/शैक्षणिक योग्यता</h3>
                <?php include_once('education_document.php');?>
        </div>
		<div class="tab-pane fade in" id="tab3">
		  <!--<div id="studinfo"></div>-->
		  <?php include_once('show_studinfo.php');?>
		</div>
          <div id='loading' class="newtop" >
                <center><img src="photo/loader.gif" style="height: 25%;position: fixed;margin-left: -4%;margin-top: 15%;"></center>
            </div>
      </div>
    </div>   
 <?php include_once ('footer.php');?>