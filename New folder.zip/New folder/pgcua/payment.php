<?php include('header.php');

$studentname = mysqli_fetch_array(mysqli_query($conn,"SELECT studentname FROM `student` where studentid='".@$_SESSION['user_id']."'"));
$query_cat = mysqli_query($conn,"SELECT t1.stud_id,t1.`stud_choice_course`, t1.`stud_semester`,t2.coursename,t3.categorey,t3.sportdquotaperson,t3.singlegirlperson,t3.culturalquotaperson FROM `studcourse` t1 INNER JOIN course t2 on t1.stud_choice_course=t2.id INNER JOIN registration t3 on t1.stud_id=t3.studid where t1.stud_id='".@$_SESSION['user_id']."'");
@$row_cat=mysqli_fetch_array($query_cat);

$query_records=mysqli_query($conn,"SELECT * FROM `registration` where studid='".@$_SESSION['user_id']."'");
 @$num_records=mysqli_num_rows($query_records);
    @$row_records=mysqli_fetch_array($query_records);


if($row_records['gender']== 'Female' and $row_records['bonafideofup'] == '1'){
    $edit_d = mysqli_query($conn,"SELECT t1.`ids`, t1.`course`, t1.`semester`,t1. `admission`, t1.`librarysecurity`,t1. `houseexam`, t1.`medical`,t1. `campuedevelop`,t1. `bookreplacement`,t1. `furniturereplacement`, t1.`identitycard`, t1.`magazine`,t1. `ncc`, t1.`studentaid`,t1. `cultural`,t1. `computer&internet`, t1.`activity`,t1. `spordsfund`,t1. `bf`,t1. `security`, t1.`rover_ranger`, t1.`unit_development_fund`, t1.`hpu_registraion`,t1.`hpu_registraion_non_hp`, t1.`hpu_continuation`, t1.`hpu_sports`, t1.`hpu_youth_welfare_fund`, t1.`hpu_holiday_home`, t1.`cmp_fee`  FROM `fee_sturture` t1 WHERE t1.course='".$row_cat['stud_choice_course']."' and t1.semester = '".$row_cat['stud_semester']."'")or die(mysqli_error($conn));
    
    $subotal = mysqli_query($conn,"SELECT (t1. `admission`+ t1.`librarysecurity`+t1. `houseexam`+ t1.`medical`+t1. `campuedevelop`+t1. `bookreplacement`+t1. `furniturereplacement`+ t1.`identitycard`+ t1.`magazine`+t1. `ncc`+ t1.`studentaid`+t1. `cultural`+t1. `computer&internet`+ t1.`activity`+t1. `spordsfund`+t1. `bf`+t1. `security`+ t1.`rover_ranger`+ t1.`unit_development_fund`+ t1.`hpu_registraion`+ t1.`hpu_continuation`+ t1.`hpu_sports`+ t1.`hpu_youth_welfare_fund`+ t1.`hpu_holiday_home`+ t1.`cmp_fee`) as subotal  FROM `fee_sturture` t1 WHERE t1.course='".$row_cat['stud_choice_course']."' and t1.semester = '".$row_cat['stud_semester']."'")or die(mysqli_error($conn));
    
}else{
    $edit_d = mysqli_query($conn,"SELECT t1.`ids`, t1.`course`, t1.`semester`,t1. `admission`, t1.`tution`, t1.`librarysecurity`,t1. `houseexam`, t1.`medical`,t1. `campuedevelop`,t1. `bookreplacement`,t1. `furniturereplacement`, t1.`identitycard`, t1.`magazine`,t1. `ncc`, t1.`studentaid`,t1. `cultural`,t1. `computer&internet`, t1.`activity`,t1. `spordsfund`,t1. `bf`,t1. `security`, t1.`rover_ranger`, t1.`unit_development_fund`, t1.`hpu_registraion`,t1.`hpu_registraion_non_hp`, t1.`hpu_continuation`, t1.`hpu_sports`, t1.`hpu_youth_welfare_fund`, t1.`hpu_holiday_home`, t1.`cmp_fee`  FROM `fee_sturture` t1 WHERE t1.course='".$row_cat['stud_choice_course']."' and t1.semester = '".$row_cat['stud_semester']."'")or die(mysqli_error($conn));
    if($row_records['bonafideofup'] == '1'){
        $subotal = mysqli_query($conn,"SELECT (t1. `admission`+ t1.`tution`+ t1.`librarysecurity`+t1. `houseexam`+ t1.`medical`+t1. `campuedevelop`+t1. `bookreplacement`+t1. `furniturereplacement`+ t1.`identitycard`+ t1.`magazine`+t1. `ncc`+ t1.`studentaid`+t1. `cultural`+t1. `computer&internet`+ t1.`activity`+t1. `spordsfund`+t1. `bf`+t1. `security`+ t1.`rover_ranger`+ t1.`unit_development_fund`+ t1.`hpu_registraion`+ t1.`hpu_continuation`+ t1.`hpu_sports`+ t1.`hpu_youth_welfare_fund`+ t1.`hpu_holiday_home`+ t1.`cmp_fee`) as subotal  FROM `fee_sturture` t1 WHERE t1.course='".$row_cat['stud_choice_course']."' and t1.semester = '".$row_cat['stud_semester']."'")or die(mysqli_error($conn));
    }else{
        $subotal = mysqli_query($conn,"SELECT (t1. `admission`+ t1.`tution`+ t1.`librarysecurity`+t1. `houseexam`+ t1.`medical`+t1. `campuedevelop`+t1. `bookreplacement`+t1. `furniturereplacement`+ t1.`identitycard`+ t1.`magazine`+t1. `ncc`+ t1.`studentaid`+t1. `cultural`+t1. `computer&internet`+ t1.`activity`+t1. `spordsfund`+t1. `bf`+t1. `security`+ t1.`rover_ranger`+ t1.`unit_development_fund`+ t1.`hpu_registraion_non_hp`+ t1.`hpu_continuation`+ t1.`hpu_sports`+ t1.`hpu_youth_welfare_fund`+ t1.`hpu_holiday_home`+ t1.`cmp_fee`) as subotal  FROM `fee_sturture` t1 WHERE t1.course='".$row_cat['stud_choice_course']."' and t1.semester = '".$row_cat['stud_semester']."'")or die(mysqli_error($conn));
    }
}
						$edit_detail = mysqli_num_rows($edit_d);
						$edit_details = mysqli_fetch_array($edit_d);


						$subotal_num = mysqli_num_rows($subotal);
						$subotal_val = mysqli_fetch_array($subotal);



$mainsubjects = mysqli_query($conn,"SELECT subject_id  FROM student_subject  where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and student_id='".@$_SESSION['user_id']."'"); 

$precticalsubjects = mysqli_query($conn,"SELECT id FROM subjects where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and pid in (SELECT subject_id  FROM student_subject  where course='".@$row_cat['stud_choice_course']."' and semester = '".@$row_cat['stud_semester']."' and student_id='".@$_SESSION['user_id']."') ");

$subdisplayfee = '';
 ?>
<div class="tab-pane fade in" id="tab4">
          <h2 style="text-align:center;">Payment</h2>
		  <!--<p style="margin-bottom:15px;">Please Choose yourmode of payment</p> <br/>
		  <input type="button" value="Offline" class="btn btn-success" onclick="printDiv('btnpayment')">
		  <input type="button" value="Online" class="btn btn-success">	-->
		  <div id="reference_id">
		  <div class="text-center">
                <h3>Fee Break Down </h3>
            </div>
			<hr>
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  
                  <div class="x_content">

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Fee Type</th>
                          <th>Fee </th>
                          <th>Fee Type</th>
                          <th>Fee</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Admission Fee</td>
							<td><input class="txt" value="<?php echo $edit_details['admission'];?>" type="text" disabled></td>
							<?php if($row_records['gender']== 'Female' and $row_records['bonafideofup'] == '1'){ }else{ ?>
                            <td>Tution Fee</td>
							<td><input class="txt"  value="<?php echo $edit_details['tution'];?>" type="text" disabled></td>
                            <?php  } ?>
                        </tr>
                        <tr>
                          <td>Library Security</td>
							<td><input class="txt" value="<?php echo $edit_details['librarysecurity'];?>" type="text" disabled></td>
							 <td>House Exam</td>
							 <td><input class="txt" value="<?php echo $edit_details['houseexam'];?>" type="text" disabled></td>
                        </tr>
                        <tr>
                          <td>Medical Fee</td>
							<td><input class="txt" value="<?php echo $edit_details['medical'];?>" type="text" disabled ></td>
						   <td>Campus development fund</td>
							<td><input class="txt" value="<?php echo $edit_details['campuedevelop'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                           <td>Book Replacement fund</td>
							<td><input class="txt" value="<?php echo $edit_details['bookreplacement'];?>" type="text" disabled ></td>
							<td>Furniture Replacement fund</td>
							<td><input class="txt" value="<?php echo $edit_details['furniturereplacement'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                          <td>Identity Card</td>
							<td><input class="txt" value="<?php echo $edit_details['identitycard'];?>" type="text" disabled ></td>
							  <td>Magazine fund</td>
							<td><input class="txt" value="<?php echo $edit_details['magazine'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                          <td>Ncc fund</td>
							<td><input class="txt" value="<?php echo $edit_details['ncc'];?>" type="text" disabled ></td>
							  <td>Student Aid fund</td>
							<td><input class="txt" value="<?php echo $edit_details['cultural'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                           <td>Cultural Activities fund</td>
							<td><input class="txt" value="<?php echo $edit_details['cultural'];?>" type="text" disabled ></td>
							<td>Computer & Internet</td>
							<td><input class="txt" value="<?php echo $edit_details['computer&internet'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                        <td>AF</td>
							<td><input class="txt" value="<?php echo $edit_details['activity'];?>" type="text" disabled ></td>
						   <td>Sports fund</td>
							<td><input class="txt" value="<?php echo $edit_details['spordsfund'];?>" type="text" disabled ></td>
                        </tr>
						<tr>
                        <td>BF</td>
						<td><input class="txt" value="<?php echo $edit_details['bf'];?>" type="text" disabled ></td>
					   <td>PTA Fund</td>
						<td><input class="txt" value="<?php echo $edit_details['security'];?>" type="text" disabled ></td>
						</tr>
						
						<tr>
                        <td>Rover & Rangers</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['rover_ranger'];?>" ></td>
					   <td>Univ Development Fund</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['unit_development_fund'];?>" ></td>
						 </tr>
						 
						 <tr>
                             <?php if($row_records['bonafideofup'] == '1'){  ?>
                        <td>HPU Registration</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_registraion'];?>" ></td>
                             <?php }else { ?>
					    <td>HPU Registration NON-HP</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_registraion_non_hp'];?>" ></td>
                             <?php } ?>
						 </tr>
						 
						 <tr>
                        <td>HPU Sports</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_sports'];?>" ></td>
					   <td>HPU Youth Welfare Fund</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_youth_welfare_fund'];?>" ></td>
						 </tr>
						 
						 <tr>
                         <td>HPU Holiday Home</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_holiday_home'];?>" ></td>
						<td>HPU Continuation</td>
						<td><input class="txt" type="text" disabled value="<?php echo $edit_details['hpu_continuation'];?>" ></td>
						 </tr>
						   <tr>
                          <td>Computer & Internet Fee</td>
						<td><input class="txt" type="text" disabled name="cmp_fee" id="cmp_fee" value="<?php echo $edit_details['cmp_fee'];?>"></td>
                         <td><b>Sub Total</b></td>
						<td><b>&#x20A8; <?php echo $subotal_val['subotal']; ?></b></td>
						 </tr>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
              <h3 style="display: block;text-align: center;margin: 20px 0;">Fee Break Down for Subject/Practical </h3>
              <div class="col-md-6 col-sm-6 col-xs-6 col-sm-offset-3">
                <div class="x_panel">
                  
                  <div class="x_content">

                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Fee Type</th>
                          <th>Fee</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php while($row = mysqli_fetch_array($mainsubjects)){ 
                                $fee = mysqli_fetch_array(mysqli_query($conn,"SELECT fee FROM `course_fee` where  subject = '".$row['subject_id']."'"));
                                $name = mysqli_fetch_array(mysqli_query($conn,"SELECT subject FROM `subjects` where  id = '".$row['subject_id']."'"));
                            if($fee['fee'] != NULL){
                                $subdisplayfee += $fee['fee'];
                          ?>
						<tr>
						    <td><?php echo $name['subject'];?></td>
				            <td><input class="txt" value="<?php echo $fee['fee'];?>" type="text" disabled ></td>
                        </tr>
                        <?php } }?>
                          
                        <?php while($row = mysqli_fetch_array($precticalsubjects)){
                                $fee = mysqli_fetch_array(mysqli_query($conn,"SELECT fee FROM `course_fee` where  subject = '".$row['id']."'"));
                                $name = mysqli_fetch_array(mysqli_query($conn,"SELECT subject FROM `subjects` where  id = '".$row['id']."'"));
                            if($fee['fee'] != NULL){
                                $subdisplayfee += $fee['fee'];
                          ?>
						<tr>
						    <td><?php echo $name['subject'];?></td>
				            <td><input class="txt" value="<?php echo $fee['fee'];?>" type="text" disabled ></td>
                        </tr>
                        <?php } }?>  
						   <tr>
                              <td><b>Sub Total</b></td>
						      <td><b>&#x20A8; <?php echo $subdisplayfee; ?></b></td>
						 </tr>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
		</div>
    <div style="clear: both;margin: 0 auto;width: 100%;text-align: center;">
        <p style="margin-bottom:15px;">Please Choose yourmode of payment</p> <br/>
		<input type="button" value="Offline" class="btn btn-success" onclick="printDiv('btnpayment')">
		<input type="button" value="Online" class="btn btn-success">
    </div>
	<div class="container" id="btnpayment" style="display:none;">
        
	<style type="text/css" media="print">
    @page { 
        size: landscape;
    }
</style>
		  <hr>
		  
    <div class="row">
        <div class="col-xs-12">
           <hr>
			<div class="container">
			  <div class="row">
				<div class="col-sm-4" style="width:30%;float:left;">
				  <h4>Student's Copy</h4>
				 <table class="table table-bordered ace">
					<thead>
					  <tr>
						<th colspan="4">College<!--<img alt="" src="<?php echo $college_logo ;?>" style="max-width: 100px;">--></th>
						<th style="font-size: 8px;" colspan="2">PAY-IN-SLIP<br>Branch Copy <br>Addmission Fee</th>
						<th colspan="3"><img alt="" src="<?php echo $bank_logo ;?>" style="height: 53px;"></th>
					  </tr>
					</thead>
					<tbody>
					  <tr>
						<td colspan="9"> <strong>Note:1</strong><small> Challan to be deposited two days after th generation pf challan</small></td>
					  </tr>
					  <tr>
						<td colspan="4">Challan No</td>
						<td colspan="5"><?php echo $set_challanstart.date("Y").$_SESSION['user_id'];?></td>
					  </tr>
					  <tr>
						<td colspan="4">Course</td>
						<td colspan="5"><?php echo $row_cat['coursename'].'-'.$row_cat['stud_semester'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="4">Candidate's Name</td>
						<td colspan="5"><?php echo $studentname['studentname'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="4">Father' Name</td>
						<td colspan="5"><?php echo $row_records['fathername'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="3"> DOB </td>
						<td><?php echo $row_records['dob'];?></td>
						<td colspan="2">PNB Branch <br>	Name </td>
						<td colspan="3">UNA </td>
					  </tr>
					  <tr>
						<td colspan="3"> Fee Type </td>
						<td> Addmission Fee	</td>
						<td colspan="2">PNB Branch <br>Code	</td>
						<td colspan="3">.........<br></td>
					  </tr>
					  <tr>
						<td colspan="3">Application Fee:<br>Challan Date:</td>
						<td><?php echo $subotal_val['subotal'] + $subdisplayfee ; ?><br><?php echo date("d/m/y");?></td>
						<td colspan="2">Desposit Date<br>Journal No<br></td>
						<td colspan="3">.........<br>.........<br></td>
					  </tr>
					   <tr class="abc">
						<td  colspan="4" class="abctd">Candidate's Signature</td>
						<td  colspan="5" class="abctd">Authorized Bank Signatory</td>

					  </tr>
					  <tr class="text">
						<td colspan="9" class="footer"><strong>Note:1</strong><small> Bank will collect Rs.20 as their charges. 2. Fee receiving branch is advised to write the Date,Journal Number and Branch Code above. 3. Bank official please go to screen 8888</small></td>
					  </tr>
					</tbody>
				  </table>
				</div>
				<div class="col-sm-4" style="width:30%;float:left;">
				  <h4>College's Copy</h4>
				  <table class="table table-bordered ace">
					<thead>
					  <tr>
					<th colspan="4">College<!--<img alt="" src="<?php echo $college_logo ;?>" style="max-width: 100px;">--></th>
						<th style="font-size: 8px;" colspan="2">PAY-IN-SLIP<br>Branch Copy <br>Addmission Fee</th>
						<th colspan="3"><img alt="" src="<?php echo $bank_logo ;?>" style="height: 53px;"></th>
					  </tr>
					</thead>
					<tbody>
					  <tr>
						<td colspan="9"> <strong>Note:1</strong><small> Challan to be deposited two days after th generation pf challan</small></td>
					  </tr>
					  <tr>
						<td colspan="4">Challan No</td>
						<td colspan="5"><?php echo $set_challanstart.date("Y").$_SESSION['user_id'];?></td>
					  </tr>
					  <tr>
						<td colspan="4">Course</td>
						<td colspan="5"><?php echo $row_cat['coursename'].'-'.$row_cat['stud_semester'];?></td>
					  </tr>
					  <tr>
						<td colspan="4">Candidate's Name</td>
						<td colspan="5"><?php echo $studentname['studentname'];?></td>
					  </tr>
					  <tr>
						<td colspan="4">Father' Name</td>
						<td colspan="5"><?php echo $row_records['fathername'];?></td>
					  </tr>
					  <tr>
						<td colspan="3">
						  DOB
						</td>
						<td>
						<?php echo $row_records['dob'];?>
						</td>
						<td colspan="2">
						PNB Branch <br>
						Name	
						</td colspan="2">
						<td colspan="3">
						UNA 
						</td>
					  </tr>
					  <tr>
						<td colspan="3">
						  Fee Type
						</td>
						<td>
						  Addmission Fee
						</td>
						<td colspan="2">
						PNB Branch <br>
						Code	
						</td>
						<td colspan="3">
						.........<br>
					
						
						</td>
					  </tr>
					  <tr>
						<td colspan="3">
						Apllication Fee:<br>
						Challan Date:
						</td>
						<td>
						<?php echo $subotal_val['subotal'] + $subdisplayfee ; ?><br>
						<?php echo date("d/m/y");?>
						
						</td>
						<td colspan="2">
						Desposit Date<br>
						Journal No<br>
						
						</td>
						<td colspan="3">
						.........<br>
						.........<br>
						
						</td>
					  </tr>
					   <tr class="abc">
						<td  colspan="4" class="abctd">Candidate's Signature</td>
						<td  colspan="5" class="abctd">Authorized Bank Signatory</td>

					  </tr>
					  <tr class="text">
						<td colspan="9" class="footer"><strong>Note:1</strong><small> Bank will collect Rs.20 as their charges. 2. Fee receiving branch is advised to write the Date,Journal Number and Branch Code above. 3. Bank official please go to screen 8888</small></td>
					   
					  </tr>
					</tbody>
				  </table>
				</div>
				<div class="col-sm-4" style="width:30%;float:left;">
				  <h4>Bank's Copy</h4>        
				  <table class="table table-bordered ace">
					<thead>
					  <tr>
						<th colspan="4">College<!--<img alt="" src="<?php echo $college_logo ;?>" style="max-width: 100px;">--></th>
					   
						<th style="font-size: 8px;" colspan="2">PAY-IN-SLIP<br>Branch Copy<br>Addmission Fee</th>
						<th colspan="3"><img alt="" src="<?php echo $bank_logo ;?>" style="height: 53px;"></th>
					  </tr>
					</thead>
					<tbody>
					  <tr>
						<td colspan="9"> <strong>Note:1</strong><small> Challan to be deposited two days after th generation pf challan</small></td>
					   
					  </tr>
					  <tr>
						<td colspan="4">Challan No</td>
						<td colspan="5"><?php echo $set_challanstart.date("Y").$_SESSION['user_id'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="4">Course</td>
						<td colspan="5"><?php echo $row_cat['coursename'].'-'.$row_cat['stud_semester'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="4">Candidate's Name</td>
						<td colspan="5"><?php echo $studentname['studentname'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="4">Father' Name</td>
						<td colspan="5"><?php echo $row_records['fathername'];?></td>
						
					  </tr>
					  <tr>
						<td colspan="3">
						  DOB
						</td>
						<td>
						<?php echo $row_records['dob'];?>
						</td>
						<td colspan="2">
						PNB Branch <br>
						Name	
						</td colspan="2">
						<td colspan="3">
						UNA 
						</td>
					  </tr>
					  <tr>
						<td colspan="3">
						  Fee Type
						</td>
						<td>
						  Addmission Fee
						</td>
						<td colspan="2">
						PNB Branch <br>
						Code	
						</td>
						<td colspan="3">
						.........<br>
					
						
						</td>
					  </tr>
					  <tr>
						<td colspan="3">
						Apllication Fee:<br>
						Challan Date:
						</td>
						<td>
						<?php echo $subotal_val['subotal'] + $subdisplayfee ; ?><br>
						<?php echo date("d/m/y");?>
						
						</td>
						<td colspan="2">
						Desposit Date<br>
						Journal No<br>
						
						</td>
						<td colspan="3">
						.........<br>
						.........<br>
						
						</td>
					  </tr>
					   <tr class="abc">
						<td  colspan="4" class="abctd">Candidate's Signature</td>
						<td  colspan="5" class="abctd">Authorized Bank Signatory</td>

					  </tr>
					  <tr class="text">
						<td colspan="9" class="footer"><strong>Note:1</strong><small> Bank will collect Rs.20 as their charges. 2. Fee receiving branch is advised to write the Date,Journal Number and Branch Code above. 3. Bank official please go to screen 8888</small></td>
					   
					  </tr>
					</tbody>
				  </table>
				</div>
			  </div>
			</div>
            
        </div>
    </div>
    
</div>
<input type="button" class="btn btn-warning" id="btnprint" style="display:none;" onclick="printDiv('btnpayment')" value="PRINT">
<?php
if(isset($_POST['submit'])){
		
	@$txtidss = $_POST['txtidss'];
	@$txtbankreferenceno = $_POST['txtbankreferenceno'];
	$res=mysqli_query($conn,"Select * from student where studentid='".$txtidss."'");
	$count = mysqli_num_rows($res);
	$row = mysqli_fetch_array($res);
	@$email = $row['studentemail'];
	$reg_no = $_POST['reg_no'];
	$dat =date('d-m-Y H:i:m');
	
    $query = mysqli_query($conn,"Insert into challan(studid,bankreferenceno,challan,date) VALUES('".$txtidss."','".$txtbankreferenceno."','".$reg_no."','".$dat."')");
        if($query){   
            echo "<script type='text/javascript'> alert('Challan submitted successfully, kindly submit the challan college copy at college office');</script>";
					  $subject2 = "Scholastic Admin";
    
    $message2 = '<div id=":1ai" class="ii gt adP adO"><div id=":1aj" class="a3s aXjCH m15a550a10a3c5f4c"><u></u>
	<div style="width:100%;margin:0px 0px 0px 0px;background-color:#ffffff;color:#272829;font-family:"Roboto",sans-serif">
	<table align="center" border="0" cellpadding="0" cellspacing="0" style="background-color:#ffffff;margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;width:100%;color:#272829;font-family:"Roboto",sans-serif">
		<tbody>
			<tr>
				<td align="center" valign="top"></td>
			</tr>
			<tr>
				<td>
					<table align="center" border="0" cellpadding="0" cellspacing="0" class="m_-9167139107518604221tablewrap" style="background-color:#ffffff;margin:20px auto 20px auto;border-color:#eeeeee;border-width:1px;border-style:solid">
					<tbody>
						<tr>
							<td align="center" valign="top">
								<table bgcolor="#FFFFFF" border="0" cellpadding="0" cellspacing="0" style="max-width:578px">
									<tbody>
										<tr>
											<td>
											<p style="margin:43px 0px 5px 50px">
												<img src="'.$mail_logo.'" width="140" height="36" style="background-color:#ffffff;color:#000000;font-size:14px;text-align:center;height: 75px;margin-left: 31%;" alt="Examrobo" class="Examrobo">
								
											</p>
											<p style="margin:35px 50px 0px 50px;word-break:break-word;font-size:24px;font-weight:bold;max-width:100%;letter-spacing:-1px;box-sizing:border-box;text-align:center">
												You have submit successfully challan and your regiration id 
											</p>
											<p style="margin:36px 50px 45px 50px;word-break:break-word;font-size:15px;font-weight:normal;max-width:100%;box-sizing:border-box;line-height:120%">
												'.$reg_no.' <br>
												<span style="margin-left: 9%;">'."</span>
											</p>

											
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>

					<tr style='background-color:#ffffff'>
						<td align='leftr' valign='top'>
							<table bgcolor='#ffffff' border='0' cellpadding='0' cellspacing='0' style='max-width:578px'>
								<tbody><tr>
									<td align='left'>
										<p style='margin:0 0 44px 50px;color:#888888;font-size:12px;line-height:20px;max-width:100%;box-sizing:border-box;text-align: center;'>
											Thank for register in Scholastic <br>
											
										</p>
									</td>
								</tr>
							</tbody></table>
						</td>
					</tr>
			</tbody>
		</table>
	</td>
</tr>

	</tbody>
</table>
	<div class='adL'></div>
	
	</div>
</div>";


$headers2  = 'MIME-Version: 1.0' . "\r\n";
//$headers2  = "CC: testexam@gmail.com \r\n";
$headers2 .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    //$headers .= "From:" . $from;
    $headers2 .= "From:" . 'www.ScholasticAdmin.com';
    
    mail($email,$subject2,$message2,$headers2); 
				}
	    	else
				{
					echo "<script type='text/javascript'> alert('You can not not submit');</script>";
				}
 
	}  
?>
		
    </div>