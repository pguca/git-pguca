-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2017 at 11:48 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `colleges`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `admin` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `super_admin` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `email`, `password`, `super_admin`, `created_at`) VALUES
(2, 'Pankaj', 'admin@gmail.com', '123', 0, '0000-00-00 00:00:00'),
(3, 'Gaurav', 'g.gauravsh@gmail.com', '12345', 0, '0000-00-00 00:00:00'),
(4, 'Gaurav', 'g.gauravsh@gmail.com', '12345', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `admissiondates`
--

CREATE TABLE IF NOT EXISTS `admissiondates` (
  `id` int(10) NOT NULL,
  `start` date NOT NULL,
  `cut` date NOT NULL,
  `end` date NOT NULL,
  `type` varchar(30) NOT NULL,
  `admin_id` varchar(10) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admissiondates`
--

INSERT INTO `admissiondates` (`id`, `start`, `cut`, `end`, `type`, `admin_id`, `created`) VALUES
(12, '2017-05-29', '2017-05-30', '2017-05-31', '2', '2', '2017-05-29 02:48:24'),
(10, '2017-05-29', '2017-05-30', '2017-05-31', '2', '2', '2017-05-29 02:42:06'),
(11, '2017-05-29', '2017-05-30', '2017-05-31', '2', '2', '2017-05-29 02:43:27'),
(13, '2017-05-30', '2017-06-22', '2017-06-30', '1', '2', '2017-05-30 08:21:30'),
(14, '2017-05-30', '2017-05-31', '2017-06-02', '1', '2', '2017-05-30 12:15:49'),
(15, '2017-05-31', '2017-06-22', '2017-06-23', '1', '2', '2017-05-31 17:26:55'),
(16, '2017-05-31', '2017-06-08', '2017-06-15', '1', '2', '2017-05-31 17:27:24'),
(17, '2017-06-01', '2017-06-23', '2017-06-30', '1', '2', '2017-06-01 08:20:49');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category`, `date`) VALUES
(1, 'General', '13-05-2017 17:41:05'),
(2, 'OBC', '13-05-2017 17:41:05'),
(3, 'ST', '13-05-2017 17:42:05'),
(4, 'SC', '13-05-2017 17:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `challan`
--

CREATE TABLE IF NOT EXISTS `challan` (
  `id` int(11) NOT NULL,
  `studid` varchar(100) DEFAULT NULL,
  `bankreferenceno` varchar(100) DEFAULT NULL,
  `challan` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `challan`
--

INSERT INTO `challan` (`id`, `studid`, `bankreferenceno`, `challan`, `date`) VALUES
(1, '".$txtidss."', '".$txtbankreferenceno."', '".$challan."', '".$dat."'),
(2, '".$txtidss."', '".$txtbankreferenceno."', '".$challan."', '".$dat."'),
(3, '18', 'hahdhd', 'temp.pdf', '09-05-2017 18:31:05'),
(4, '18', 'DDASDA', 'temp.pdf', '09-05-2017 19:01:05'),
(5, '18', 'dasdasd', 'temp.pdf', '09-05-2017 19:17:05'),
(6, '18', 'asdasdsad', 'ckstaff testing comments 29-11-2016.pdf', '10-05-2017 00:25:05'),
(7, '18', '213123123', 'ckstaff testing comments 29-11-2016.pdf', '10-05-2017 01:14:05'),
(8, '".$txtidss."', '".$txtbankreferenceno."', '".$matricsheet."', '".$dat."'),
(9, '18', '23123123', 'ck.pdf', '10-05-2017 08:08:05'),
(10, '18', '15151', 'temp.pdf', '10-05-2017 11:14:05'),
(11, '18', '234324234234', 'demoform1.pdf', '10-05-2017 23:04:05'),
(12, '23', '34234234234', 'ck.pdf', '13-05-2017 01:05:05'),
(13, '', '23123', 'ck.pdf', '13-05-2017 02:23:05'),
(14, '23', '156456151', 'cks.pdf', '18-05-2017 18:25:05'),
(15, '23', '23423432', 'cks.pdf', '18-05-2017 18:30:05'),
(16, '23', '15616165', 'abc', '18-05-2017 19:33:05'),
(17, '23', '234234', 'cks.pdf', '18-05-2017 19:36:05'),
(18, '23', '15616165', 'cks.pdf', '18-05-2017 19:40:05'),
(19, '23', '15616516516', 'abc', '18-05-2017 20:01:05'),
(20, '23', '15481512', 'HPU232017BA002', '19-05-2017 12:52:05'),
(21, '44', '422312321', 'HPU442017BA002', '19-05-2017 18:33:05');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `id` int(11) NOT NULL,
  `CourseCat` int(1) NOT NULL DEFAULT '1' COMMENT '"1" => Graduation and "2" => Post Graduation',
  `CourseType` int(1) NOT NULL,
  `coursename` varchar(100) NOT NULL,
  `available_seats` varchar(10) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `coursedate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `CourseCat`, `CourseType`, `coursename`, `available_seats`, `duration`, `coursedate`) VALUES
(42, 1, 1, 'BSc with computer Science', '120', '6', '18-05-17'),
(43, 1, 2, 'BA', '', '6', '18-05-17'),
(44, 1, 1, 'BSc Life Sciences', '120', '6', '18-05-17'),
(31, 1, 2, 'B.Com', '240', '6', '11-05-17'),
(40, 1, 1, 'BSc Physical Science', '120', '6', '18-05-17'),
(46, 1, 2, 'testertest', '50', '10', '19-05-17'),
(47, 1, 2, 'testertest', '40', '10', '19-05-17'),
(48, 1, 2, 'testertest', '10', '6', '19-05-17'),
(49, 1, 1, 'bsc crime', '20', '10', '19-05-17'),
(50, 2, 1, 'Msc.', '40', '7', '19-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `coursecat`
--

CREATE TABLE IF NOT EXISTS `coursecat` (
  `Id` int(10) NOT NULL,
  `TermID` varchar(30) NOT NULL,
  `CourseTerm` varchar(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursecat`
--

INSERT INTO `coursecat` (`Id`, `TermID`, `CourseTerm`) VALUES
(1, 'Core Subjects', '1'),
(2, 'Skill Enhancement Course', '2'),
(3, 'Ability ', '3'),
(4, 'Practical Subject', '4');

-- --------------------------------------------------------

--
-- Table structure for table `coursetype`
--

CREATE TABLE IF NOT EXISTS `coursetype` (
  `Id` int(10) NOT NULL,
  `TermID` varchar(30) NOT NULL,
  `CourseTerm` varchar(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursetype`
--

INSERT INTO `coursetype` (`Id`, `TermID`, `CourseTerm`) VALUES
(1, 'Merit', '1'),
(2, 'Non Merit', '2');

-- --------------------------------------------------------

--
-- Table structure for table `course_fee`
--

CREATE TABLE IF NOT EXISTS `course_fee` (
  `id` int(10) NOT NULL,
  `subject` int(11) NOT NULL,
  `course` varchar(25) NOT NULL,
  `semester` varchar(25) NOT NULL,
  `fee` varchar(25) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_fee`
--

INSERT INTO `course_fee` (`id`, `subject`, `course`, `semester`, `fee`, `created`) VALUES
(18, 48, '43', '1', '90', '2031-05-17 00:00:00'),
(19, 49, '43', '1', '123', '2003-06-17 00:00:00'),
(20, 54, '', '', '100', '0000-00-00 00:00:00'),
(21, 55, '', '', '100', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `course_semester`
--

CREATE TABLE IF NOT EXISTS `course_semester` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `semester_seats` int(11) NOT NULL,
  `semester_min_core_subjects` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fee_sturture`
--

CREATE TABLE IF NOT EXISTS `fee_sturture` (
  `ids` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `admission` decimal(10,0) NOT NULL,
  `tution` decimal(10,0) NOT NULL,
  `librarysecurity` decimal(10,0) NOT NULL,
  `houseexam` decimal(10,0) NOT NULL,
  `medical` decimal(10,0) NOT NULL,
  `campuedevelop` decimal(10,0) NOT NULL,
  `bookreplacement` decimal(10,0) NOT NULL,
  `furniturereplacement` decimal(10,0) NOT NULL,
  `identitycard` decimal(10,0) NOT NULL,
  `magazine` decimal(10,0) NOT NULL,
  `ncc` decimal(10,0) NOT NULL,
  `studentaid` decimal(10,0) NOT NULL,
  `cultural` decimal(10,0) NOT NULL,
  `computer&internet` decimal(10,0) NOT NULL,
  `activity` decimal(10,0) NOT NULL,
  `spordsfund` decimal(10,0) NOT NULL,
  `bf` decimal(10,0) NOT NULL,
  `security` decimal(10,0) NOT NULL,
  `date` datetime NOT NULL,
  `rover_ranger` decimal(10,0) NOT NULL,
  `unit_development_fund` decimal(10,0) NOT NULL,
  `hpu_registraion` decimal(10,0) NOT NULL,
  `hpu_registraion_non_hp` decimal(10,0) NOT NULL,
  `hpu_continuation` decimal(10,0) NOT NULL,
  `hpu_sports` decimal(10,0) NOT NULL,
  `hpu_youth_welfare_fund` decimal(10,0) NOT NULL,
  `hpu_holiday_home` decimal(10,0) NOT NULL,
  `cmp_fee` decimal(10,0) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee_sturture`
--

INSERT INTO `fee_sturture` (`ids`, `course`, `semester`, `admission`, `tution`, `librarysecurity`, `houseexam`, `medical`, `campuedevelop`, `bookreplacement`, `furniturereplacement`, `identitycard`, `magazine`, `ncc`, `studentaid`, `cultural`, `computer&internet`, `activity`, `spordsfund`, `bf`, `security`, `date`, `rover_ranger`, `unit_development_fund`, `hpu_registraion`, `hpu_registraion_non_hp`, `hpu_continuation`, `hpu_sports`, `hpu_youth_welfare_fund`, `hpu_holiday_home`, `cmp_fee`) VALUES
(6, 42, 4, '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '2017-06-04 17:17:00', '19', '20', '21', '22', '26', '23', '24', '25', '27'),
(5, 43, 1, '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '2017-06-04 15:29:00', '19', '20', '21', '22', '26', '23', '24', '25', '27'),
(3, 31, 1, '250', '300', '100', '40', '6', '10', '25', '10', '10', '50', '5', '20', '20', '1', '150', '120', '60', '300', '2017-06-01 13:57:00', '30', '250', '210', '410', '0', '15', '15', '1', '90');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL,
  `fathername` varchar(100) NOT NULL,
  `mothername` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `annualsalary` varchar(100) NOT NULL,
  `address` longtext NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `tehsil` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `address2` longtext NOT NULL,
  `country2` varchar(100) NOT NULL,
  `state2` varchar(100) NOT NULL,
  `city2` varchar(100) NOT NULL,
  `district2` varchar(100) NOT NULL,
  `tehsil2` varchar(100) NOT NULL,
  `pincode2` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `categorey` varchar(100) NOT NULL,
  `irdp` varchar(100) NOT NULL,
  `sports` varchar(100) NOT NULL,
  `ncc` varchar(100) NOT NULL,
  `nss` varchar(100) NOT NULL,
  `bonafideofup` varchar(100) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `fatherno` varchar(100) NOT NULL,
  `landlineno` varchar(100) NOT NULL,
  `marriedstatus` varchar(100) NOT NULL,
  `studid` bigint(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sportdquotaperson` varchar(100) DEFAULT NULL,
  `singlegirlperson` varchar(100) DEFAULT NULL,
  `culturalquotaperson` varchar(100) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fathername`, `mothername`, `gender`, `occupation`, `annualsalary`, `address`, `country`, `state`, `city`, `district`, `tehsil`, `pincode`, `address2`, `country2`, `state2`, `city2`, `district2`, `tehsil2`, `pincode2`, `dob`, `categorey`, `irdp`, `sports`, `ncc`, `nss`, `bonafideofup`, `nationality`, `mobileno`, `fatherno`, `landlineno`, `marriedstatus`, `studid`, `date`, `sportdquotaperson`, `singlegirlperson`, `culturalquotaperson`) VALUES
(12, 'fathername lastname', 'mothername motherlname', 'male', 'occupation', '1231231231', '                                                                ads                                                                ', 'country', 'state', 'city', 'district', 'tesh', '123123', '                                                                ads                                                                ', 'country', 'state', 'city', 'district', 'tesh', '123123', '2017-05-10', '1', '0', '0', '0', '0', '0', '0', '2222222222', '9023805175', '2222222222', '0', 11, '2017-06-04 21:35:56', '0', '0', '0'),
(6, 'BANSI LAL', 'KRISHNA DEVI', 'male', 'RETD', '250000', 'VPO LALHARI TEH HAROLI DISTT UNA', 'INDIA', 'HP', 'UNA', 'UNA', 'HAROLI', '174301', 'VPO LALHARI TEH HAROLI DISTT UNA', 'INDIA', 'HP', 'UNA', 'UNA', 'HAROLI', '174301', '1985-02-06', '1', '0', '1', '0', '1', '1', '1', '9816803823', '9817254161', '', '0', 14, '2017-05-24 09:15:07', '0', '0', '0'),
(7, 'Avinash Chander Sharma', 'Raj  Sharma', 'male', 'Anganwadi worker', '111111111', '                        V.P.O. Santokhgarh Teh. & Distt. Una Himachal Pradesh, Pin Code: 174301                        ', 'India', 'Himachal Pradesh', 'Una', 'Una', 'Una', '174301', '                        V.P.O. Santokhgarh Teh. & Distt. Una Himachal Pradesh, Pin Code: 174301                        ', 'India', 'Himachal Pradesh', 'Una', 'Una', 'Una', '174301', '1990-01-07', '1', '1', '1', '1', '1', '1', '1', '8894840481', '7406582031', '2222222222', '0', 12, '2017-06-04 18:23:25', '1', '1', '0'),
(8, 'Avinash Sharma', 'Raj Sharma', '', 'Teacher', '50000', '                                ', 'india', 'himachal', 'santokhgarh', 'una', 'una', '174301', '                                ', 'india', 'himachal', 'santokhgarh', 'una', 'una', '174301', '1994-02-01', '1', '0', '0', '0', '0', '0', '0', '4444444', '444444', '', '0', 17, '2017-05-25 06:05:53', '0', '0', '0'),
(13, 'Chiranji  Lal', 'mother lubana', 'male', 'retd', '44444444', '                MP Kothi', 'India', 'Punjab', 'Nangal', 'Ropar', 'Anandpur ', '111111', '                MP Kothi', 'India', 'Punjab', 'Nangal', 'Ropar', 'Anandpur ', '111111', '07-03-1976', '1', '0', '0', '0', '0', '1', '1', '9418066250', '9357608909', '', '0', 22, '2017-06-02 09:02:10', '0', '0', '0'),
(10, 'Satish Kumar Sharma', 'Neelam Sharma', 'male', 'Retd', '250000', '          Village-Sunehra                                                                                                                                                                                        ', 'india', 'Himachal', 'una', 'una', 'una', '174303', '          Village-Sunehra                                                                                                                                                                                        ', 'india', 'Himachal', 'una', 'una', 'una', '174303', '1983-03-04', '1', '0', '0', '0', '0', '1', '1', '9816512299', '9318727375', '', '1', 19, '2017-06-03 16:45:40', '0', '0', '0'),
(11, 'Ravinder Sharma', 'Veena Sharma', 'male', 'Govt Job', '300000', '                                        House No 123, Ward No : 5                        ', 'India', 'Himachal Pradesh', 'Santokhgarh', 'Una', 'Una', '174301', '                                        House No 123, Ward No : 5                        ', 'India', 'Himachal Pradesh', 'Santokhgarh', 'Una', 'Una', '174301', '1985-01-06', '1', '0', '0', '0', '0', '0', '0', '9736204600', '9318036057', '', '1', 20, '2017-06-03 15:34:22', '0', '0', '1'),
(14, 'Ravinder Sharma', 'Veena Sharma', 'male', 'Govt Job', '300000', '                123/5', 'India', 'Himachal Pradesh', 'Santokhgarh', 'Una', 'Una', '174301', '                123/5', 'India', 'Himachal Pradesh', 'Santokhgarh', 'Una', 'Una', '174301', '1984-01-05', '1', '0', '0', '0', '0', '0', '0', '9736204600', '9318036057', '', '0', 2, '2017-06-03 17:01:50', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `semester_details`
--

CREATE TABLE IF NOT EXISTS `semester_details` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `core_subject_count` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester_details`
--

INSERT INTO `semester_details` (`id`, `course_id`, `semester_id`, `core_subject_count`) VALUES
(2, 43, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `studcourse`
--

CREATE TABLE IF NOT EXISTS `studcourse` (
  `id` int(11) NOT NULL,
  `stud_id` varchar(100) NOT NULL,
  `stud_choice_course` varchar(100) NOT NULL,
  `stud_semester` varchar(100) NOT NULL,
  `studdate` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studcourse`
--

INSERT INTO `studcourse` (`id`, `stud_id`, `stud_choice_course`, `stud_semester`, `studdate`) VALUES
(1, '5', '43', '3', '24-05-2017 03:53:05 '),
(2, '14', '33', '1', '24-05-2017 14:45:05 '),
(24, '19', '42', '1', '04-06-2017 23:00:06 '),
(34, '11', '43', '1', '05-06-2017 01:29:06 '),
(5, '17', '42', '5', '25-05-2017 11:39:05 '),
(6, '18', '31', '3', '26-05-2017 16:23:05 '),
(22, '12', '43', '1', '04-06-2017 12:45:06 '),
(20, '20', '43', '1', '04-06-2017 12:03:06 '),
(30, '2', '42', '2', '05-06-2017 01:14:06 '),
(10, '22', '31', '1', '02-06-2017 14:32:06 ');

-- --------------------------------------------------------

--
-- Table structure for table `studdocument`
--

CREATE TABLE IF NOT EXISTS `studdocument` (
  `stud_docid` int(11) NOT NULL,
  `matricboard` varchar(100) NOT NULL,
  `matricyear` varchar(100) NOT NULL,
  `matricredit` varchar(100) NOT NULL,
  `matricgetmarks` float NOT NULL,
  `matrictotalmarks` varchar(100) NOT NULL,
  `matricpercentage` float NOT NULL,
  `matricrollno` varchar(100) NOT NULL,
  `matricfile` varchar(100) NOT NULL,
  `2board` varchar(100) NOT NULL,
  `2year` varchar(100) NOT NULL,
  `2credit` varchar(100) NOT NULL,
  `2getmarks` float NOT NULL,
  `2totalmarks` varchar(100) NOT NULL,
  `2percentage` float NOT NULL,
  `2rollno` varchar(100) NOT NULL,
  `2file` varchar(100) NOT NULL,
  `gruad` varchar(100) NOT NULL,
  `gruadpass` varchar(100) NOT NULL,
  `gruadboard` varchar(100) NOT NULL,
  `gruadyear` varchar(100) NOT NULL,
  `gruadcredit` varchar(100) NOT NULL,
  `gruadgetmarks` float NOT NULL,
  `gruadtotalmarks` varchar(100) NOT NULL,
  `gruadpercentage` float NOT NULL,
  `gruadrollno` varchar(100) NOT NULL,
  `gruadfile` varchar(100) NOT NULL,
  `regingrate` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `signature` varchar(100) NOT NULL,
  `character` varchar(100) NOT NULL,
  `castcertificate` varchar(100) NOT NULL,
  `singlegirlcertificate` varchar(100) NOT NULL,
  `sportslcertificate` varchar(100) NOT NULL,
  `culturalcertificate` varchar(100) NOT NULL,
  `studid` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studdocument`
--

INSERT INTO `studdocument` (`stud_docid`, `matricboard`, `matricyear`, `matricredit`, `matricgetmarks`, `matrictotalmarks`, `matricpercentage`, `matricrollno`, `matricfile`, `2board`, `2year`, `2credit`, `2getmarks`, `2totalmarks`, `2percentage`, `2rollno`, `2file`, `gruad`, `gruadpass`, `gruadboard`, `gruadyear`, `gruadcredit`, `gruadgetmarks`, `gruadtotalmarks`, `gruadpercentage`, `gruadrollno`, `gruadfile`, `regingrate`, `photo`, `signature`, `character`, `castcertificate`, `singlegirlcertificate`, `sportslcertificate`, `culturalcertificate`, `studid`, `date`, `status`) VALUES
(3, 'HP BOARD', '2007', '', 455, '700', 65, '2222', 'Index.pdf', 'HP BOARD', '2016', '', 222, '500', 44.4, '3333', 'Index.pdf', '', 'Not_Applicable', '', '', '', 0, '', 0, '', '', 'No', '1387.jpg', '1618.jpg', 'Index.pdf', '', '', '', '', '14', '2017-05-24 09:18:39', '0'),
(4, 'sadasd', '1987', '', 150, ' 450', 33.3333, '1515411', 'demoform1.pdf', 'wqeqwe', '1988', '', 450, '650', 69.2308, '45151', 'demoform1.pdf', '44', 'Passed', ' sadwedasds', '1989', '', 1541, ' 2500', 61.64, '485484', 'demoform1.pdf', 'No', 'demoform1.pdf', 'demoform1.pdf', 'demoform1.pdf', '', '', '', '', '18', '2017-05-26 10:55:13', '0'),
(5, 'hpbse', '2014', '', 497, '700', 71, '12', 'Physics_Major_UG_Syllabus.pdf', 'hpbse', '2016', '', 261, '400', 65.25, '23', 'Physics_Major_UG_Syllabus.pdf', '', 'Not_Applicable', '', '', '', 0, '', 0, '', '', 'No', 'IMG-20170530-WA0046.jpg', 'IMG-20170530-WA0046.jpg', 'IMG-20170530-WA0045.jpg', '', '', '', '', '19', '2017-05-31 07:43:57', '0'),
(6, 'CBSE', '2014', '', 325, '500', 65, '8234824', 'certificate.jpeg', 'HPSEB', '2016', '', 325, '500', 65, '3458738', 'IMM5476E Use of Representative.pdf', '', 'Not_Applicable', '', '', '', 0, '', 0, '', '', 'No', 'adhaar.jpeg', 'certificate.jpeg', 'IMM5476E Use of Representative.pdf', '', '', '', 'IMM5476E Use of Representative.pdf', '20', '2017-06-02 06:30:41', '0'),
(7, 'HPBSE', '2014', '', 504, '700', 72, '420', 'Car Battery.pdf', 'HPBSE', '2016', '', 325, '400', 81.25, '420', 'Car Battery.pdf', '', 'Not_Applicable', '', '', '', 0, '', 0, '', '', 'No', 'IMG-20160803-WA0012.jpg', 'durga.jpg', 'Car Battery.pdf', '', '', '', '', '22', '2017-06-02 09:05:09', '0'),
(8, 'fdfdfdfd', '1986', '', 32, '32', 100, '232323', '1.pdf', 'fdfdfdf', '1986', '', 34, '34', 100, '223323', '10th.PDF', '', 'Awaited', '', '', '', 0, '', 0, '', '', 'No', 'Sap.jpg', 'Sap.jpg', 'Sap.jpg', '', 'Sap.jpg', 'Sap.jpg', '', '12', '2017-06-04 08:13:32', '0'),
(9, 'sd', '1985', '', 555, '555', 100, '555', 'Avin_The IT Company - Copy (2).pdf', 'asdasd', '1999', '', 555, '555', 100, '555', 'Avin_The IT Company - Copy (3).pdf', '44', 'Passed', 'asd', '1999', '', 555, '555', 100, '555', 'Avin_The IT Company - Copy (4).pdf', 'No', 'Roster.jpg', 'Roster.jpg', 'Avin_The IT Company.pdf', '', '', '', '', '11', '2017-06-04 08:28:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `studentid` int(11) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `studentemail` varchar(100) NOT NULL,
  `studentuidno` varchar(100) NOT NULL,
  `studentpassword` varchar(100) NOT NULL,
  `studentdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(100) NOT NULL,
  `migrate` varchar(100) NOT NULL,
  `terminate` varchar(100) NOT NULL,
  `isactive` varchar(100) NOT NULL,
  `rollnumber` varchar(50) NOT NULL,
  `regnumber` varchar(50) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentid`, `studentname`, `studentemail`, `studentuidno`, `studentpassword`, `studentdate`, `status`, `migrate`, `terminate`, `isactive`, `rollnumber`, `regnumber`) VALUES
(11, 'pkapila', 'prashantkapila6@gmail.com', '111122222221', '213ee683360d88249109c2f92789dbc3', '2017-06-04 19:46:12', '1', '1', '1', '0', '1212', '123'),
(12, 'Pankaj Sharma', 'erpnkjsharma@gmail.com', '232323322222', '9b6b249ca27284311db1df1aae014ea8', '2017-05-31 17:57:43', '1', '0', '0', '0', '', '234'),
(13, 'Pankaj Sharma', 'er.pnkjsharma@gmail.com', '123333333333', '9b6b249ca27284311db1df1aae014ea8', '2017-05-24 08:29:43', '0', '', '', '0', '', ''),
(14, 'Achhar', 'bagga.achhar@gmail.com', '444444444444', 'e10adc3949ba59abbe56e057f20f883e', '2017-05-24 09:09:43', '1', '', '', '0', '', ''),
(15, 'hhhhhh', 'e.rpnkjsharma@gmail.com', '123456789111', '38945f926270561d770cd9796ca1e0a3', '2017-05-25 04:14:38', '0', '', '', '0', '', ''),
(16, '12vqdy213-d/', 'DFSDF@FDSF.COM', '121233423412', '6324818e8f4f49837ae0283b9c9c6fdc', '2017-05-25 05:20:46', '0', '', '', '0', '', ''),
(17, 'aaaaa', 'shubhamsharma.lpp@gmail.com', '123456789123', '8cacfecf715626c5b1e39394d46d1e13', '2017-05-31 15:50:31', '1', '1', '', '0', '', ''),
(21, 'Rahul Sharma', 'sumitphysics@yahoo.com', '666666666666', 'd4aebee46e8120b233d6f020d02d7bd4', '2017-06-02 07:32:16', '0', '', '', '0', '', ''),
(19, 'Sumit Sharma', 'sumitphysics@gmail.com', '222222333333', 'd4aebee46e8120b233d6f020d02d7bd4', '2017-05-28 04:41:41', '1', '', '', '0', '', ''),
(20, 'Gaurav Sharma', 'g.gauravsh@gmail.com', '123456789', '71f18aea5d376a94c94141b7828d7c8d', '2017-05-28 06:24:07', '1', '', '', '0', '', ''),
(22, 'Madan', 'gera_phy_hpu@yahoo.co.in', '256056551100', 'b895703dcef82cad2ef74fcade0adae9', '2017-06-02 08:49:25', '1', '', '', '0', '', ''),
(23, 'Madan', 'yogitlobana@hotmail.com', '111122223333', '92a7529528463391582326bc3ca9b227', '2017-06-02 08:48:46', '0', '', '', '0', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_admission_collection`
--

CREATE TABLE IF NOT EXISTS `student_admission_collection` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `deposit_date` date NOT NULL,
  `method_ofPayment` int(11) NOT NULL,
  `admission_fee` decimal(10,0) NOT NULL,
  `tution_fee` decimal(10,0) NOT NULL,
  `library_security` decimal(10,0) NOT NULL,
  `house_exam` decimal(10,0) NOT NULL,
  `medical` decimal(10,0) NOT NULL,
  `campus_develop` decimal(10,0) NOT NULL,
  `book_replacement` decimal(10,0) NOT NULL,
  `furniture_replacement` decimal(10,0) NOT NULL,
  `identity_card` decimal(10,0) NOT NULL,
  `magazine_fund` decimal(10,0) NOT NULL,
  `ncc` decimal(10,0) NOT NULL,
  `student_aid` decimal(10,0) NOT NULL,
  `cultural_activities` decimal(10,0) NOT NULL,
  `comp_internet` decimal(10,0) NOT NULL,
  `af` decimal(10,0) NOT NULL,
  `sports_fund` decimal(10,0) NOT NULL,
  `bf` decimal(10,0) NOT NULL,
  `Pta_fund` decimal(10,0) NOT NULL,
  `rover_ranger` decimal(10,0) NOT NULL,
  `univ_develop` decimal(10,0) NOT NULL,
  `hpu_registration_hp` decimal(10,0) NOT NULL,
  `hpu_registration_non_hp` decimal(10,0) NOT NULL,
  `hpu_continuation` decimal(10,0) NOT NULL,
  `hpu_sports` decimal(10,0) NOT NULL,
  `hpu_youth_welfare_fund` decimal(10,0) NOT NULL,
  `hpu_holiday_fund` decimal(10,0) NOT NULL,
  `comp_fee` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_admission_collection`
--

INSERT INTO `student_admission_collection` (`id`, `student_id`, `deposit_date`, `method_ofPayment`, `admission_fee`, `tution_fee`, `library_security`, `house_exam`, `medical`, `campus_develop`, `book_replacement`, `furniture_replacement`, `identity_card`, `magazine_fund`, `ncc`, `student_aid`, `cultural_activities`, `comp_internet`, `af`, `sports_fund`, `bf`, `Pta_fund`, `rover_ranger`, `univ_develop`, `hpu_registration_hp`, `hpu_registration_non_hp`, `hpu_continuation`, `hpu_sports`, `hpu_youth_welfare_fund`, `hpu_holiday_fund`, `comp_fee`) VALUES
(1, 9, '2017-06-01', 1, '1', '2', '3', '4', '5', '6', '7', '0', '8', '9', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '28', '24', '29', '25', '26', '27'),
(2, 7, '2017-06-02', 1, '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '15', '16', '17', '18', '19', '20', '22', '23', '24', '25', '26', '27', '28', '29', '30'),
(3, 5, '2017-06-02', 1, '22', '33', '45', '56', '67', '8', '99', '2', '13', '33', '55', '66', '22', '77', '17', '18', '19', '20', '22', '23', '24', '25', '26', '27', '28', '29', '30');

-- --------------------------------------------------------

--
-- Table structure for table `student_document_satus`
--

CREATE TABLE IF NOT EXISTS `student_document_satus` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `doc_type` varchar(100) NOT NULL,
  `document` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(100) NOT NULL COMMENT '"Accept" OR "Deny"',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_document_satus`
--

INSERT INTO `student_document_satus` (`id`, `student_id`, `doc_type`, `document`, `message`, `status`, `created_at`) VALUES
(0, 19, 'Metric', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:58:18'),
(0, 19, 'Metric', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:58:48'),
(0, 19, 'Metric', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:58:50'),
(0, 19, 'Metric', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:58:50'),
(0, 19, 'Secondary', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:58:55'),
(0, 19, 'Photo', 'IMG-20170530-WA0046.jpg', '', 'Accept', '2017-06-01 18:58:59'),
(0, 19, 'Signature', 'IMG-20170530-WA0046.jpg', '', 'Accept', '2017-06-01 18:59:00'),
(0, 19, 'Character', 'Physics_Major_UG_Syllabus.pdf', '', 'Accept', '2017-06-01 18:59:01');

-- --------------------------------------------------------

--
-- Table structure for table `student_special_fee_collection`
--

CREATE TABLE IF NOT EXISTS `student_special_fee_collection` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `deposit_date` date NOT NULL,
  `subject_id` int(11) NOT NULL,
  `amount_deposited` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_special_fee_collection`
--

INSERT INTO `student_special_fee_collection` (`id`, `student_id`, `deposit_date`, `subject_id`, `amount_deposited`) VALUES
(1, 9, '2017-06-01', 51, '5000'),
(2, 10, '2017-06-01', 19, '5000'),
(3, 11, '2017-06-01', 52, '5000');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE IF NOT EXISTS `student_subject` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`id`, `student_id`, `subject_id`, `course`, `semester`, `time`) VALUES
(18, 11, 48, 43, 1, '2017-06-04 20:00:10'),
(19, 11, 40, 43, 1, '2017-06-04 20:00:10'),
(20, 11, 44, 43, 1, '2017-06-04 20:00:10'),
(21, 11, 49, 43, 1, '2017-06-04 20:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `stud_message`
--

CREATE TABLE IF NOT EXISTS `stud_message` (
  `id` int(11) NOT NULL,
  `stud_regid` varchar(100) NOT NULL,
  `message` longtext NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `message_type` varchar(100) NOT NULL COMMENT '''Send message to "All" Or "Single" student''',
  `students_id` varchar(100) NOT NULL COMMENT 'If message to all students then save comma seperated student Id',
  `phone` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_message`
--

INSERT INTO `stud_message` (`id`, `stud_regid`, `message`, `admin_id`, `message_type`, `students_id`, `phone`, `date`) VALUES
(1, '19', 'Hi this message is for testing purpose', '', 'single', '', '9816512299', '2017-06-04 05:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `stud_migrate`
--

CREATE TABLE IF NOT EXISTS `stud_migrate` (
  `id` int(11) NOT NULL,
  `stud_regid` varchar(100) NOT NULL,
  `migration` longtext NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_migrate`
--

INSERT INTO `stud_migrate` (`id`, `stud_regid`, `migration`, `admin_id`, `date`) VALUES
(1, '11', 'hhhh', '2', '2017-05-31 15:49:58'),
(2, '11', 'hhhh', '2', '2017-05-31 15:50:04'),
(3, '11', 'hhhh', '2', '2017-05-31 15:50:07'),
(4, '11', 'hhhh', '2', '2017-05-31 15:50:08'),
(5, '11', 'hhhh', '2', '2017-05-31 15:50:13'),
(6, '11', 'hhhh', '2', '2017-05-31 15:50:14'),
(7, '17', 'hhhh', '2', '2017-05-31 15:50:31'),
(8, '17', 'hhhh', '2', '2017-05-31 15:50:33'),
(9, '17', 'hhhh', '2', '2017-05-31 15:50:37'),
(10, '12', 'Testing Migration.', '2', '2017-05-31 17:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `stud_terminate`
--

CREATE TABLE IF NOT EXISTS `stud_terminate` (
  `id` int(11) NOT NULL,
  `stud_regid` varchar(100) NOT NULL,
  `terminate_message` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_terminate`
--

INSERT INTO `stud_terminate` (`id`, `stud_regid`, `terminate_message`, `admin_id`, `date`) VALUES
(1, '5', '', '2', '2017-05-29 19:32:22'),
(2, '5', '', '2', '2017-05-29 19:32:35'),
(3, '11', 'hhhh', '2', '2017-05-31 15:50:21'),
(4, '11', 'hhhh', '2', '2017-05-31 15:50:22'),
(5, '11', 'hhhh', '2', '2017-05-31 15:50:23'),
(6, '12', 'Terminate testing.', '2', '2017-05-31 17:55:15');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `subjectmodifiable` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `pid`, `type`, `subject`, `course`, `semester`, `subjectmodifiable`, `created`) VALUES
(41, 0, '1', 'Public Administration', '43', '1', 1, '2017-06-04 06:53:21'),
(39, 0, '1', 'Political Science', '43', '1', 1, '2017-06-04 06:53:21'),
(37, 0, '1', '', 'Select', '1', 0, '2017-06-04 06:48:34'),
(36, 0, '1', '', 'Select', 'Select', 1, '2017-06-04 06:48:12'),
(34, 0, '1', 'Chemistry', '44', '1', 0, '2017-06-04 06:37:14'),
(35, 0, '3', '', 'Select', 'Select', 0, '2017-06-04 06:50:23'),
(33, 0, '1', 'Botany', '44', '1', 0, '2017-06-04 06:37:14'),
(32, 0, '1', 'Zoology', '44', '1', 0, '2017-06-04 06:37:14'),
(31, 0, '3', 'Environmental Science', '42', '1', 0, '2017-06-04 06:35:31'),
(40, 0, '1', 'History', '43', '1', 1, '2017-06-04 06:53:21'),
(19, 0, '1', 'physics', '40', '1', 0, '2017-06-03 16:03:18'),
(20, 0, '1', 'chemistry', '40', '1', 0, '2017-06-03 16:03:18'),
(30, 0, '1', 'Mathematics', '42', '1', 0, '2017-06-04 06:35:31'),
(28, 0, '1', 'Computer science', '42', '1', 0, '2017-06-04 06:35:31'),
(29, 0, '1', 'Physics', '42', '1', 0, '2017-06-04 06:35:31'),
(25, 0, '1', 'Mathematics', '40', '1', 0, '2017-06-03 17:04:17'),
(26, 0, '3', 'Environmental Science', '40', '1', 0, '2017-06-03 17:04:17'),
(42, 0, '1', 'Economics', '43', '1', 1, '2017-06-04 06:53:21'),
(43, 0, '1', 'Mathematics', '43', '1', 1, '2017-06-04 06:53:21'),
(44, 0, '1', 'Geography', '43', '1', 1, '2017-06-04 06:53:21'),
(45, 0, '1', 'Journalism and Mass Comunicati', '43', '1', 1, '2017-06-04 06:53:21'),
(46, 0, '1', 'Music(vocal)', '43', '1', 1, '2017-06-04 06:53:21'),
(47, 0, '1', 'Music(instrumental)', '43', '1', 1, '2017-06-04 06:53:21'),
(48, 0, '1', 'English Compulsory', '43', '1', 0, '2017-06-04 06:53:21'),
(49, 0, '3', 'Hindi', '43', '1', 1, '2017-06-04 06:53:21'),
(51, 0, '3', 'Sanskrit', '43', '1', 1, '2017-06-04 06:53:21'),
(52, 0, '1', 'Hindi Core', '43', '1', 1, '2017-06-04 07:16:41'),
(54, 48, '4', 'practical 1', '43', '1', 0, '0000-00-00 00:00:00'),
(55, 49, '4', 'practical 2', '43', '1', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `subject_restrict`
--

CREATE TABLE IF NOT EXISTS `subject_restrict` (
  `id` int(10) NOT NULL,
  `course` varchar(30) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `subject1` varchar(30) NOT NULL,
  `subject2` varchar(30) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `subject_restrict`
--

INSERT INTO `subject_restrict` (`id`, `course`, `semester`, `subject1`, `subject2`, `created`) VALUES
(9, '43', '1', '41', '39', '2017-06-04 07:18:35'),
(10, '43', '1', '40', '43', '2017-06-04 07:23:03'),
(7, '43', '1', '52', '53', '2017-06-04 07:18:35'),
(11, '43', '1', '45', '44', '2017-06-04 07:23:03'),
(12, '43', '1', '42', '46', '2017-06-04 07:23:03'),
(13, '43', '1', '42', '47', '2017-06-04 07:24:22'),
(14, '43', '1', '46', '47', '2017-06-04 07:24:22'),
(18, '43', '1', '53', '51', '2017-06-04 10:06:57'),
(17, '43', '1', '52', '53', '2017-06-04 10:05:46');

-- --------------------------------------------------------

--
-- Table structure for table `uploaded_admission_challan`
--

CREATE TABLE IF NOT EXISTS `uploaded_admission_challan` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `challan_number` varchar(255) NOT NULL,
  `journal_number` varchar(255) NOT NULL,
  `images` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploaded_admission_challan`
--

INSERT INTO `uploaded_admission_challan` (`id`, `student_id`, `challan_number`, `journal_number`, `images`, `image_path`, `status`, `created_at`) VALUES
(1, 5, 'sdas13131', 'sdasda12321312', 'challan.JPG', 'http://nextechss.com', 0, '2017-05-30 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admissiondates`
--
ALTER TABLE `admissiondates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `challan`
--
ALTER TABLE `challan`
  ADD UNIQUE KEY `tbl_id` (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coursecat`
--
ALTER TABLE `coursecat`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `coursetype`
--
ALTER TABLE `coursetype`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `course_fee`
--
ALTER TABLE `course_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_semester`
--
ALTER TABLE `course_semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_sturture`
--
ALTER TABLE `fee_sturture`
  ADD PRIMARY KEY (`ids`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester_details`
--
ALTER TABLE `semester_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studcourse`
--
ALTER TABLE `studcourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studdocument`
--
ALTER TABLE `studdocument`
  ADD PRIMARY KEY (`stud_docid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `student_special_fee_collection`
--
ALTER TABLE `student_special_fee_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_message`
--
ALTER TABLE `stud_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_migrate`
--
ALTER TABLE `stud_migrate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_terminate`
--
ALTER TABLE `stud_terminate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_restrict`
--
ALTER TABLE `subject_restrict`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploaded_admission_challan`
--
ALTER TABLE `uploaded_admission_challan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `admissiondates`
--
ALTER TABLE `admissiondates`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `challan`
--
ALTER TABLE `challan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `coursecat`
--
ALTER TABLE `coursecat`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `coursetype`
--
ALTER TABLE `coursetype`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `course_fee`
--
ALTER TABLE `course_fee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `course_semester`
--
ALTER TABLE `course_semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fee_sturture`
--
ALTER TABLE `fee_sturture`
  MODIFY `ids` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `semester_details`
--
ALTER TABLE `semester_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `studcourse`
--
ALTER TABLE `studcourse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `studdocument`
--
ALTER TABLE `studdocument`
  MODIFY `stud_docid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `stud_message`
--
ALTER TABLE `stud_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stud_migrate`
--
ALTER TABLE `stud_migrate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `stud_terminate`
--
ALTER TABLE `stud_terminate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `subject_restrict`
--
ALTER TABLE `subject_restrict`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `uploaded_admission_challan`
--
ALTER TABLE `uploaded_admission_challan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
